// pages/setting/setting.js

const app = getApp()
const db = wx.cloud.database()
const _ = db.command

Page({

  /**
   * 页面的初始数据
   */
  data: {
    user: {
      'nickname': '',
      'sign': '',
      'img': ''
    },
    newImg: '',
    loading: false
  },

  async changeUserNickname()
  {
    let nickname = this.data.user.nickname

    wx.showModal({
      title: '用户名',
      editable: true,
      content: nickname,
      complete: (res) => {
        if (res.confirm) {
          this.setData({
            'user.nickname': res.content
          })
        }
      }
    })
  },

  async changeUserSign()
  {
    let sign = this.data.user.sign

    wx.showModal({
      title: '个性签名',
      editable: true,
      content: sign,
      complete: (res) => {
        if (res.confirm) {
          this.setData({
            'user.sign': res.content
          })
        }
      }
    })
  },

  ChooseImage() {
    wx.chooseImage({
      count: 1, // 强制设置只能选1张
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'], // 建议加上 camera，方便用户拍照
      success: (res) => {
        // 直接取返回数组的第一个元素，赋值给字符串 newImg
        this.setData({
          newImg: res.tempFilePaths[0]
        })
      }
    });
  },
  ViewImage() {
    wx.previewImage({
      // urls 必须是数组，所以我们要把字符串包装进数组里
      urls: [this.data.newImg], 
      current: this.data.newImg
    });
  },
  DelImg() {
    wx.showModal({
      title: '提示',
      content: '确定要删除这张图片吗？\r\n留空将不做修改',
      cancelText: '取消',
      confirmText: '确定',
      success: res => {
        if (res.confirm) {
          // 直接将字符串设为空即可
          this.setData({
            newImg: ''
          })
        }
      }
    })
  },

  async submitForm()
  {
    let user = this.data.user
    let newImg = this.data.newImg
    let loading = this.data.loading
    // 防止重复提交
    if (loading)
      return

    this.setData({
      loading: true
    })

    wx.showLoading({
      title: '保存中...',
      mask: true
    })

    try {
      let uploadImg = user.img; // 默认值：原头像

      // 只有当 newImg 存在，且是新选的本地图片时，才需要执行上传
      if (newImg && (newImg.startsWith('http') || newImg.startsWith('wxfile'))) {
        const uploadRes = await wx.cloud.uploadFile({
          cloudPath: `setting/userImg/${user._id}-${Date.now()}.png`,
          filePath: newImg // 确保这里是本地路径
        });
        uploadImg = uploadRes.fileID;
      } 
      // 情况2：如果 newImg 为空，uploadImg 保持 user.img 不变（留空不修改）
      // 情况3：如果 newImg 是 cloud:// 路径，uploadImg = newImg 也相当于没变

      await db.collection('Students').doc(user._id).update({
        data: {
          nickname: user.nickname,
          sign: user.sign,
          img: uploadImg
        }
      });

      user.img = uploadImg
      wx.setStorageSync('user', user)
      app.globalData.user = user
      
      wx.showToast({
        title: '保存成功',
        icon: 'success',
        mask: true
      })
    } catch (error) {
      wx.showToast({
        title: '保存失败',
        icon: 'error'
      })
    } finally {
      this.setData({
        loading: false
      })
    }
  },

  onLoadUser: function()
  {
    let user = app.globalData.user

    this.setData({
      user: user,
      newImg: user.img
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.onLoadUser()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})