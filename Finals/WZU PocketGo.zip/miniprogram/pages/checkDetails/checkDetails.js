const db = wx.cloud.database()
Page({

    /**
     * 页面的初始数据
     */
    data: {
      claimData: {
        
      },
      itemInfo: {

      }
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
      const claimData = JSON.parse(decodeURIComponent(options.claimData))
      console.log(claimData)
      this.setData({
        claimData: claimData
      })
      this.getItemInfo()
    },
    // 获取物品信息
    async getItemInfo() {
      const itemId = this.data.claimData.itemId
      const res = await db.collection('LostandFoundItems').doc(itemId).get()
      if (res.data) {
        this.setData({
          itemInfo: res.data
        })
      }
    },
    // 点击按钮复制联系方式
  getPhone() {
    const phone = this.data.claimData.phone
    wx.showModal({
      title: '联系方式',
      content: phone,
      confirmText: '复制',
      complete: (res) => {
        if (res.confirm) {
          wx.setClipboardData({
            data: phone,
            success: (res) => {
              wx.showToast({
                title: '复制成功',
                icon: 'success',
                duration: 1000
              })
            }
          })
        }
      }
    })
  },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})