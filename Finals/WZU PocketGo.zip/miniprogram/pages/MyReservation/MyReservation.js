// pages/Classroom_Reservation/MyReservation/MyReservation.js
const app = getApp()

Page({
    data: {
      TabCur: 0,
      scrollLeft: 0,
      statusList:['待审核','已通过','已结束'],
      reservations:[[],[],[]],
      pageSize: 10,
      currentPage: 2,
      hasMore: true,
    },
    NavToNewPage(e){
      const dst=e.currentTarget.dataset.cur;
      wx.redirectTo({
        url: '../'+dst+'/'+dst,
      })
    },
    tabSelect(e) {
      this.setData({
        TabCur: e.currentTarget.dataset.id,
        scrollLeft: (e.currentTarget.dataset.id - 1) * 60
      })
    },
    ListTouchStart(e) {
      this.setData({
        ListTouchStart: e.touches[0].pageX
      })
    },
    ListTouchMove(e) {
      this.setData({
        ListTouchDirection: e.touches[0].pageX - this.data.ListTouchStart > 0 ? 'right' : 'left'
      })
    },
    ListTouchEnd(e) {
      if (this.data.ListTouchDirection == 'left') {
        this.setData({
          modalName: e.currentTarget.dataset.target
        })
      } else {
        this.setData({
          modalName: null
        })
      }
      this.setData({
        ListTouchDirection: null
      })
    },
    tabSelect(e) {
      this.setData({
        TabCur: e.currentTarget.dataset.id,
        scrollLeft: (e.currentTarget.dataset.id - 1) * 60,
        reservations: { pending: [], approved: [], ended: [] },
        currentPage: 1,
        hasMore: true,
      });
      this.fetchReservations();
    },
    async fetchReservations() {
      const db = wx.cloud.database();
      const submittedApplication = db.collection('submittedApplication');
      let user = app.globalData.user
      let result = await submittedApplication.count()
      let total = result.total
      let limit = this.data.pageSize
      let batchTime = Math.ceil(total / limit)
      let task = []

      for (let i = 0; i < batchTime; i++) {
        let subtask = submittedApplication.where({
          'userId': user._id
        })
        .skip(i * limit)
        .limit(limit)
        .get()

        task.push(subtask)
      }

      let res = await Promise.all(task);
      //console.log('查询结果:', res);
      const reservations = [[], [], []];

      for (let i = 0; i < res.length; i++) {
        for (let j = 0; j < res[i].data.length; j++) {
          if (res[i].data[j].status === 0) {
            reservations[0].push(res[i].data[j])
          } else if (res[i].data[j].status === 1) {
            reservations[1].push(res[i].data[j]) 
          } else {
            reservations[2].push(res[i].data[j]) 
          }
        }
      }

      this.setData({
        reservations: reservations, 
        currentPage: this.data.currentPage + 1,
      });
    },
    onReachBottom() {
      if (this.data.hasMore) {
        this.fetchReservations(); 
      } else {
        wx.showToast({
          title: '没有更多数据了',
          icon: 'none',
        });
      }
    },
    onPullDownRefresh() {
      this.setData({
        reservations: { pending: [], approved: [], ended: [] },
        currentPage: 1,
        hasMore: true, 
      });
      this.fetchReservations();
      wx.stopPullDownRefresh();
    },
    cancelReservation(e) {
      const reservationId = e.currentTarget.dataset.id;
      //console.log(e);
      const db = wx.cloud.database();
      const submittedApplication = db.collection('submittedApplication');
    
      wx.showModal({
        title: '确认取消',
        content: '您确定要取消这项预约吗？',
        success: async (res) => {
          if (res.confirm) {
            try {
              await submittedApplication.doc(reservationId).update({
                data: {
                  status: 3,
                }
              });
              let newReservations = this.data.reservations;
              newReservations[0] = newReservations[0].filter(item => item._id !== reservationId);
              newReservations[1] = newReservations[1].filter(item => item._id !== reservationId); 
              newReservations[2] = newReservations[2].filter(item => item._id !== reservationId);  
    
              this.setData({
                reservations: newReservations,
              });
    
              wx.showToast({
                title: '取消成功',
                icon: 'success',
              });
    
            } catch (err) {
              //console.error('取消预约失败:', err);
              wx.showToast({
                title: '取消失败，请稍后重试',
                icon: 'none',
              });
            }
          }
        }
      });
    },
    editReservationInformation(e) {
      const reservationId = e.currentTarget.dataset.id;
      
      wx.showModal({
        title: '确认修改',
        content: '修改预约将先取消当前申请，是否继续？',
        success: async (res) => {
          if (res.confirm) {
            wx.showLoading({ title: '处理中...' });
            try {
              const db = wx.cloud.database();
              // 1. 更新数据库状态为已取消/待修改 (状态码根据业务定义，假设3为取消)
              await db.collection('submittedApplication').doc(reservationId).update({
                data: { status: 3 }
              });
    
              // 2. 更新本地状态，移除当前项
              let newReservations = this.data.reservations;
              for (let i = 0; i < 3; i++) {
                newReservations[i] = newReservations[i].filter(item => item._id !== reservationId);
              }
    
              this.setData({
                reservations: newReservations,
              });
    
              wx.hideLoading();
    
              // 3. 跳转到预订页面，并携带ID，以便在新页面获取旧数据填充表单
              wx.redirectTo({
                url: `../Room_Booking/Room_Booking?editId=${reservationId}`,
              });
    
            } catch (err) {
              wx.hideLoading();
              //console.error('操作失败:', err);
              wx.showToast({
                title: '操作失败',
                icon: 'none',
              });
            }
          }
        }
      });
    },

    onLoad(options) {
      this.fetchReservations();
    },
    onReady() {

    },
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})