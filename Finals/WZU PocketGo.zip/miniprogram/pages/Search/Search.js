const db = wx.cloud.database();

Page({
  data: {
    TabCurIndex: 0, 
    NavIndex: 0, 
    NavList: ['按时间查', '按教室查'],
    SEMESTER_START_DATE: '2025-09-08',
    showFlag: false, 
    times: [
      ['08:20', '09:00', 1], ['09:05', '09:45', 2], ['10:05', '10:45', 3],
      ['10:50', '11:30', 4], ['11:35', '12:15', 5], ['13:30', '14:10', 6],
      ['14:15', '14:55', 7], ['15:15', '15:55', 8], ['16:00', '16:40', 9],
      ['16:45', '17:25', 10], ['18:30', '19:10', 11], ['19:15', '19:55', 12],
      ['20:00', '20:40', 13], ['20:45', '21:25', 14]
    ],

    year: 0,
    month: 0,
    today: 0,
    space: 0,
    day: [],
    show: false, 
    lunarDate: '',
    checkTimePicker: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],
    checkTimeIndex: 0,
    availableRooms: [],
    allRooms: ['5A-102', '5A-103', '5A-202', '5A-203', '5A-204', '5B-206', '5B-211', '5A-302', '5A-303', '5A-304', '5A-101', '5A-201', '5A-301', '5B-318'],
    classroomTypePicker: ['普通教室', '阶梯教室', '会议室'],
    classroomTypeIndex: 0,
    standardClassroomPicker: ['5A-102', '5A-103', '5A-104', '5A-202', '5A-203', '5A-204', '5B-206', '5B-211', '5A-302', '5A-303', '5A-304'],
    lectureHallClassroomPicker: ['5A-101', '5A-201', '5A-301'],
    meetingRoomPicker: ['5B-318'],
    Picker: [],
    index: 0,
    freeTimesByDay: [],
    TabCur: 0,
    
    lunarInfo: [0x04bd8, 0x04ae0, 0x0a570, 0x054d5, 0x0d260, 0x0d950, 0x16554, 0x056a0, 0x09ad0, 0x055d2, 0x04ae0, 0x0a5b6, 0x0a4d0, 0x0d250, 0x1d255, 0x0b540, 0x0d6a0, 0x0ada2, 0x095b0, 0x14977, 0x04970, 0x0a4b0, 0x0b4b5, 0x06a50, 0x06d40, 0x1ab54, 0x02b60, 0x09570, 0x052f2, 0x04970, 0x06566, 0x0d4a0, 0x0ea50, 0x06e95, 0x05ad0, 0x02b60, 0x186e3, 0x092e0, 0x1c8d7, 0x0c950, 0x0d4a0, 0x1d8a6, 0x0b550, 0x056a0, 0x1a5b4, 0x025d0, 0x092d0, 0x0d2b2, 0x0a950, 0x0b557, 0x06ca0, 0x0b550, 0x15355, 0x04da0, 0x0a5d0, 0x14573, 0x052d0, 0x0a9a8, 0x0e950, 0x06aa0, 0x0aea6, 0x0ab50, 0x04b60, 0x0aae4, 0x0a570, 0x05260, 0x0f263, 0x0d950, 0x05b57, 0x056a0, 0x096d0, 0x04dd5, 0x04ad0, 0x0a4d0, 0x1d4d4, 0x0d250, 0x0d558, 0x0b540, 0x0b5a0, 0x195a6, 0x095b0, 0x049b0, 0x0a974, 0x0a4b0, 0x0b27a, 0x06a50, 0x06d40, 0x0af46, 0x0ab60, 0x09570, 0x04af5, 0x04970, 0x064b0, 0x074a3, 0x0ea50, 0x06b58, 0x055c0, 0x0ab60, 0x096d5, 0x092e0, 0x0c960, 0x0d954, 0x0d4a0, 0x0da50, 0x07552, 0x056a0, 0x0abb7, 0x025d0, 0x092d0, 0x0cab5, 0x0a950, 0x0b4a0, 0x0baa4, 0x0ad50, 0x055d9, 0x04ba0, 0x0a5b0, 0x15176, 0x052b0, 0x0a930, 0x07954, 0x06aa0, 0x0ad50, 0x05b52, 0x04b60, 0x0a6e6, 0x0a4e0, 0x0d260, 0x0ea65, 0x0d530, 0x05aa0, 0x076a3, 0x096d0, 0x04bd7, 0x04ad0, 0x0a4d0, 0x1d0b6, 0x0d250, 0x0d520, 0x0dd45, 0x0b5a0, 0x056d0, 0x055b2, 0x049b0, 0x0a577, 0x0a4b0, 0x0aa50, 0x1b255, 0x06d20, 0x0ada0],
    chineseNumber: ["一", "二", "三", "四", "五", "六", "七", "八", "九", "十", "冬", "腊"]
  },

  onLoad(options) {
    this.getNowTime();
    this.getSpace();
    this.createDay();
    this.emit();
    this.getLunarDate(new Date());

    this.setData({
      Picker: this.data.standardClassroomPicker
    });
  },

  tabSelect(e) {
    let id = e.currentTarget.dataset.id;
    this.setData({
      NavIndex: id,
      showFlag: false
    });
  },

  innerTabSelect(e) {
    this.setData({
      TabCur: e.currentTarget.dataset.id
    });
  },

  NavToNewPage(e) {
    const dst = e.currentTarget.dataset.cur;
    wx.redirectTo({
      url: '../' + dst + '/' + dst,
    })
    //console.log(e)
  },
  checkTimeChange(e) {
    this.setData({ checkTimeIndex: e.detail.value });
  },

  submitQurey() {
    const selectedDate = `${this.data.year}-${this.data.month}-${this.data.today}`;
    const weekInfo = this.convertDateToWeek(selectedDate);
    this.getAvailableRooms(weekInfo.weekNumber, weekInfo.weekdayName, selectedDate);
  },

  async getAvailableRooms(weekNumber, weekday, selectedDate) {
    const selectedTime = this.data.checkTimePicker[this.data.checkTimeIndex];
    const occupiedRooms = new Set();
    wx.showLoading({ title: '查询中...' });

    try {
      const courseRes = await db.collection('Course_Schedule').where({
        day_of_week: weekday,
        week: db.command.in([weekNumber])
      }).get();
      courseRes.data.forEach(c => {
        if (c.time_of_day.includes(selectedTime)) occupiedRooms.add(c.site);
      });

      const appRes = await db.collection('submittedApplication').where({
        date: selectedDate,
        status: 1
      }).get();
      appRes.data.forEach(a => {
        if (a.occupiedTimes.includes(selectedTime)) occupiedRooms.add(a.classroomName);
      });

      const availableRooms = this.data.allRooms.filter(room => !occupiedRooms.has(room));
      this.setData({ availableRooms, showFlag: true });
    } catch (err) {
      console.error(err);
    } finally {
      wx.hideLoading();
    }
  },

  classroomTypeChange(e) {
    const value = e.detail.value;
    const lists = [this.data.standardClassroomPicker, this.data.lectureHallClassroomPicker, this.data.meetingRoomPicker];
    this.setData({
      classroomTypeIndex: value,
      Picker: lists[value],
      index: 0
    });
  },

  classroomNameChange(e) {
    this.setData({ index: e.detail.value });
  },

  submit() {
    this.getRecentSevenDays();
    this.getAvailableTimes();
  },

  getRecentSevenDays() {
    const today = new Date();
    const format = (d) => `${d.getFullYear()}-${(d.getMonth() + 1).toString().padStart(2, '0')}-${d.getDate().toString().padStart(2, '0')}`;
    const sevenDaysLater = new Date();
    sevenDaysLater.setDate(today.getDate() + 6);
    this.setData({
      startDate: format(today),
      endDate: format(sevenDaysLater)
    });
  },

  async getAvailableTimes() {
    const roomName = this.data.Picker[this.data.index];
    if (!roomName) return wx.showToast({ title: '请选择教室', icon: 'none' });

    wx.showLoading({ title: '查询中...' });
    const recentDays = [];
    let curr = new Date(this.data.startDate);
    for (let i = 0; i < 7; i++) {
      const d = new Date(curr);
      d.setDate(curr.getDate() + i);
      recentDays.push(`${d.getFullYear()}-${(d.getMonth() + 1).toString().padStart(2, '0')}-${d.getDate().toString().padStart(2, '0')}`);
    }

    try {
      const promises = recentDays.map(date => this.getAvailableTimesForDay(date, roomName));
      const results = await Promise.all(promises);
      const structured = results.map((times, i) => {
        const info = this.convertDateToWeek(recentDays[i]);
        return { date: recentDays[i], weekdayName: info.weekdayName, availableTimes: times };
      });
      this.setData({ freeTimesByDay: structured, showFlag: true });
    } finally {
      wx.hideLoading();
    }
  },

  async getAvailableTimesForDay(date, roomName) {
    const info = this.convertDateToWeek(date);
    const occupied = new Set();
    
    const courseRes = await db.collection('Course_Schedule').where({
      site: roomName,
      day_of_week: info.weekdayName,
      week: db.command.in([info.weekNumber])
    }).get();
    courseRes.data.forEach(c => c.time_of_day.forEach(t => occupied.add(t)));

    const appRes = await db.collection('submittedApplication').where({
      classroomName: roomName,
      date: date,
      status: 1
    }).get();
    appRes.data.forEach(a => a.occupiedTimes.forEach(t => occupied.add(t)));

    return [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14].filter(t => !occupied.has(t));
  },

  convertDateToWeek(date) {
    const startDate = new Date(this.data.SEMESTER_START_DATE);
    const targetDate = new Date(date);
    const diff = Math.round((targetDate - startDate) / (1000 * 3600 * 24));
    const weekNumber = Math.floor(diff / 7) + 1;
    const weekdays = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
    return { weekNumber, weekdayName: weekdays[targetDate.getDay()] };
  },
  getNowTime() {
    const time = new Date();
    this.setData({ year: time.getFullYear(), month: time.getMonth() + 1, today: time.getDate() });
  },
  getSpace() {
    let time = new Date(this.data.year, this.data.month - 1, 1);
    this.setData({ space: time.getDay() });
  },
  createDay() {
    let day = [];
    let len = new Date(this.data.year, this.data.month, 0).getDate();
    for (let i = 1; i <= len; i++) {
      let time = new Date(this.data.year, this.data.month - 1, i);
      day.push({ day: i, lunar: this.getLunarDate(time) });
    }
    this.setData({ day });
  },
  click(e) { this.setData({ today: e.currentTarget.dataset.today }); this.emit(); },
  setShow() { this.setData({ show: true }); },
  hideModal() { this.setData({ show: false }); },
  last() {let m = this.data.month; if(m==1){ this.setData({year:this.data.year-1, month:12})}else{this.setData({month:m-1})} this.getSpace(); this.createDay(); },
  next() {let m = this.data.month; if(m==12){ this.setData({year:this.data.year+1, month:1})}else{this.setData({month:m+1})} this.getSpace(); this.createDay(); },
  emit() {this.getLunarDate(new Date(this.data.year, this.data.month-1, this.data.today)); },

  yearDays(y) {var s=348; for(var i=0x8000;i>0x8;i>>=1) if((this.data.lunarInfo[y-1900]&i)!=0) s+=1; return s+this.leapDays(y);},
  leapDays(y) { if(this.leapMonth(y)!=0) return (this.data.lunarInfo[y-1900]&0x10000)?30:29; return 0;},
  leapMonth(y) { return this.data.lunarInfo[y-1900]&0xf; },
  monthDays(y,m) { return (this.data.lunarInfo[y-1900]&(0x10000>>m))?30:29; },
  getChinaDayString(d) { var s=["初","十","廿","卅"]; var n=d%10==0?9:d%10-1; if(d==10)return "初十"; return s[parseInt(d/10)]+this.data.chineseNumber[n];},
  getLunarDate(date) { 
    return "农历";
  }
})