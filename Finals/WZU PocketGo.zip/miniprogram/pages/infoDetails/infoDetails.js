// pages/infoDetails/infoDetails.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    itemInfo: {

    },
  },
  // 点击按钮复制联系方式
  getPhone() {
    const phone = this.data.itemInfo.phone
    wx.showModal({
      title: '联系方式',
      content: phone,
      confirmText: '复制',
      complete: (res) => {
        if (res.confirm) {
          wx.setClipboardData({
            data: phone,
            success: (res) => {
              wx.showToast({
                title: '复制成功',
                icon: 'success',
                duration: 1000
              })
            }
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    const info = JSON.parse(decodeURIComponent(options.info))
    console.log(info)
    // imgList里的地址是云存储的FileID或者下载地址时，
    // JSON.stringify()能把对象转换为字符串，
    // 但JSON.parse()不能把字符串转换回对象。
    // 怎么办？
    if (info) {
      this.setData({
        itemInfo: info
      })
    }
    // console.log(this.data.itemInfo)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})