const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    selectType: null, // 初始状态都未选中
    messageInfo: {
      id: '',
      type: '',
      name: '',
      date: '',
      region: '',
      phone: '',
      desc: '',
      imgList: []
    },
    imgList: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    const id = options.id
    if (id) {
      db.collection('LostandFoundItems').where({
        _id: id
      }).get({
        success: (res) => {
          const item = res.data[0]
          this.setData({
            selectType: item.type,
            messageInfo: {
              id: item._id,
              name: item.name,
              date: item.date,
              region: item.region,
              phone: item.phone,
              desc: item.desc,
              imgList: item.imgList
            },
            imgList: item.imgList
          })
        }
      })
    }
  },

  // 选择类型：寻物或寻主
  selectType(event) {
    const type = event.currentTarget.dataset.type
    // 如果点击的是已选中的按钮，则取消选中；否则选中该按钮
    const newType = this.data.selectType === type ? null : type
    this.setData({
      selectType: newType
    })
  },

  getName(e) {
    this.setData({
      'messageInfo.name': e.detail.value
    })
  },

  getDate(e) {
    this.setData({
      'messageInfo.date': e.detail.value
    })
  },

  getRegion(e) {
    this.setData({
      'messageInfo.region': e.detail.value
    })
  },

  getPhone(e) {
    this.setData({
      'messageInfo.phone': e.detail.value
    })
  },

  getDesc(e) {
    this.setData({
      'messageInfo.desc': e.detail.value.trim()
    })
  },

  clearDesc() {
    this.setData({
      'messageInfo.desc': ''
    })
  },

  // 显示选择出的图片
  ViewImage(e) {
    wx.previewImage({
      urls: this.data.imgList,
      current: e.currentTarget.dataset.url
    });
  },

  // 删除选择的图片
  DelImg(e) {
    wx.showModal({
      title: '提示',
      content: '确定要删除图片吗？',
      cancelText: '取消',
      confirmText: '确定',
      success: res => {
        if (res.confirm) {
          this.data.imgList.splice(e.currentTarget.dataset.index, 1);
          this.setData({
            imgList: this.data.imgList
          })
        }
      }
    })
  },

  // 选择图片
  ChooseImage() {
    var imgList = this.data.imgList
    wx.chooseMedia({
      count: 6 - imgList.length,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        var tempFiles = res.tempFiles
        tempFiles.forEach(item => {
          imgList.unshift(item.tempFilePath)
        })
        this.setData({
          imgList: imgList
        })
      }
    })
  },

  // 发布启事
  async publishMessage() {
    const user = wx.getStorageSync('user')
    const type = this.data.selectType
    const name = this.data.messageInfo.name
    const date = this.data.messageInfo.date
    const region = this.data.messageInfo.region
    const phone = this.data.messageInfo.phone
    const desc = this.data.messageInfo.desc
    const id = this.data.messageInfo.id
    var imgList = this.data.imgList

    if (type === null || !name || !date || !region || !phone) {
      wx.showToast({
        title: '请填完必填项（类型、名称、日期、地点、联系方式）',
        icon: 'none'
      })
      return
    }
    wx.showLoading({
      title: '正在上传',
    })
    // 上传图片到云存储里，并修改imgList里的临时地址为上传后的FileID
    for (let i = 0; i < imgList.length; i++) {
      const item = imgList[i]
      // 只上传临时文件地址，跳过已经是云存储FileID的文件
      if (!item.startsWith('cloud://')) {
        const uploadRes = await wx.cloud.uploadFile({
          filePath: item,
          cloudPath: `lostandfound-items/${Math.floor(Math.random() * 1000)}-${new Date().getTime()}.png`
        })
        // 替换临时文件路径为云存储FileID
        imgList[i] = uploadRes.fileID
      }
    }
    if (id) {
      db.collection('LostandFoundItems').doc(id).update({
        data: {
          type: type,
          name: name,
          date: date,
          region: region,
          phone: phone,
          desc: desc,
          imgList: imgList,
          publishTime: Date.now(),
          publisher: user._id
        },
        success: (res) => {
          wx.navigateBack({
            success: (res) => {
              wx.hideLoading()
              wx.showToast({
                title: '修改成功！',
                icon: 'success',
              })
            }
          })
        }
      })
    } else {
      db.collection('LostandFoundItems').add({
        data: {
          type: type,
          name: name,
          date: date,
          region: region,
          phone: phone,
          desc: desc,
          imgList: imgList,
          publishTime: Date.now(),
          publisher: user._id
        },
        success: (res) => {
          wx.navigateBack({
            success: (res) => {
              wx.hideLoading()
              wx.showToast({
                title: '发布成功！',
                icon: 'success',
              })
            }
          })
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})