// pages/Classroom_Reservation/Review_Application/Review_Application.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
      TabCur: 0,
      scrollLeft: 0,
      statusList:['待审核','已审核'],
      reservations:[[],[]],
      pageSize: 10,
      currentPage: 1,
      hasMore: true,

    },
    toPage(e){
      const item = e.currentTarget.dataset.item;
      //console.log(item);
      wx.redirectTo({
        url: `./DetailPage/DetailPage?id=${item._id}`,
      })
    },
    tabSelect(e) {
      this.setData({
        TabCur: e.currentTarget.dataset.id,
        scrollLeft: (e.currentTarget.dataset.id - 1) * 60
      })
    },
    async fetchReservations() {
      const db = wx.cloud.database();
      const submittedApplication = db.collection('submittedApplication');
      let result = await submittedApplication.count()
      let total = result.total
      let limit = this.data.pageSize
      let batchTime = Math.ceil(total / limit)
      let task = []

      for (let i = 0; i < batchTime; i++) {
        let subtask = submittedApplication.skip(i * limit).limit(limit).get()

        task.push(subtask)
      }

      let res = await Promise.all(task)
      //console.log('查询结果:', res);
      const reservations = [[], []];
      
      for (let i = 0; i < res.length; i++) {
        for (let j = 0; j < res[i].data.length; j++) {
          if (res[i].data[j].status === 0) {
            reservations[0].push(res[i].data[j])
          } else {
            reservations[1].push(res[i].data[j])
          }
        }
      }

      this.setData({
        reservations: reservations,
        currentPage: this.data.currentPage + 1,
      });
    },
    onReachBottom() {
      if (this.data.hasMore) {
        this.fetchReservations(); 
      } else {
        wx.showToast({
          title: '没有更多数据了',
          icon: 'none',
        });
      }
    },
    onPullDownRefresh() {
      this.setData({
        reservations: { pending: [], approved: [], ended: [] },
        currentPage: 1,
        hasMore: true, 
      });
      this.fetchReservations();
      wx.stopPullDownRefresh();
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
      this.fetchReservations();
    },


    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})