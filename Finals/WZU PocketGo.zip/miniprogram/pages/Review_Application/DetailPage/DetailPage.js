// pages/Classroom_Reservation/Review_Application/DetailPage/DetailPage.js
const app = getApp()

Page({
  data: {
    itemId: '',
    item: {},
  },

  backToReview() {
    wx.redirectTo({
      url: '../Review_Application'
    })
  },

  rejectApplication() {
    const db = wx.cloud.database();
    wx.showLoading({ title: '处理中...' });

    db.collection('submittedApplication').doc(this.data.itemId).update({
      data: { status: 4 },
    }).then(res => {
      wx.hideLoading();
      this.backToReview();
    }).catch(err => {
      wx.hideLoading();
      wx.showToast({ title: '驳回失败', icon: 'none' });
    });
  },

  approveApplication() {
    const db = wx.cloud.database();
    const _ = db.command;
    const { itemId, item } = this.data;

    wx.showLoading({ title: '处理中...' });

    db.collection('submittedApplication').doc(itemId).update({
      data: { status: 1 },
    }).then(() => {
      return db.collection('submittedApplication').where({
        _id: _.neq(itemId),
        classroom: item.classroom,
        date: item.date,
        timeSlot: item.timeSlot,
        status: 0 
      }).update({
        data: {
          status: 4
        }
      });
    }).then(res => {
      wx.hideLoading();
      wx.showToast({ title: '已通过' });
      setTimeout(() => { this.backToReview(); }, 1500);
    }).catch(err => {
      wx.hideLoading();
      wx.showToast({ title: '操作失败', icon: 'none' });
    });
  },

  onLoad(options) {
    this.setData({ itemId: options.id });
    const db = wx.cloud.database();
    
    db.collection('submittedApplication').doc(options.id).get()
      .then(res => {
        this.setData({ item: res.data });
      })
      .catch(err => {
        wx.showToast({ title: '数据加载失败', icon: 'none' });
      });
  },

  onReady() {},
  onShow() {},
  onHide() {},
  onUnload() {},
  onPullDownRefresh() {},
  onReachBottom() {},
  onShareAppMessage() {}
})