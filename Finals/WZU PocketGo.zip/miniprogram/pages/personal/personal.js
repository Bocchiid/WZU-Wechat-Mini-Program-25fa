// pages/personal/personal.js

const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    user: {
      'nickname': '',
      'sign': '',
      'img': ''
    },
    iconOtherList: [ {
      icon: 'mark',
      color: 'blue',
      name: '给我们留言',
      bindtap: "leaveMessage"
    }, {
      icon: 'mail',
      color: 'blue',
      name: '投诉我们',
      bindtap: "feedback"
    }, {
      icon: 'repeal',
      color: 'blue',
      name: '切换账号',
      bindtap: "changeAccount"
    }, {
      icon: 'settings',
      color: 'blue',
      name: '设置',
      bindtap: "setting"
    }]
  },

  leaveMessage: function()
  {
    wx.navigateTo({
      url: '../leaveMessage/leaveMessage',
    })
  },

  feedback: function()
  {
    wx.showModal({
      title: '投诉邮箱',
      content: '487883857@qq.com',
      showCancel: false,
      confirmText: '我知道了',
      confirmColor: '#007AFF'
    })
  },

  changeAccount: function()
  {
    wx.removeStorageSync('user', '')
    app.globalData.user = null

    wx.reLaunch({
      url: '../login/login',
    })
  },

  setting: function()
  {
    wx.navigateTo({
      url: '../setting/setting',
    })
  },

  onLoadUser: function()
  {
    let user = app.globalData.user
    this.setData({
      user: user
    })
  }, 

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.onLoadUser()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.onLoadUser()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})