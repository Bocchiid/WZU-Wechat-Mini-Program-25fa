// pages/home/home.js

const app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    CustomBar: app.globalData.CustomBar,
    swiperList: [{
      url: 'cloud://cloud1-8gylym58ae4d6da9.636c-cloud1-8gylym58ae4d6da9-1382384471/home/swiper images/1.jpg'
    }, {
      url: 'cloud://cloud1-8gylym58ae4d6da9.636c-cloud1-8gylym58ae4d6da9-1382384471/home/swiper images/2.jpg',
    }, {
      url: 'cloud://cloud1-8gylym58ae4d6da9.636c-cloud1-8gylym58ae4d6da9-1382384471/home/swiper images/3.jpg'
    }, {
      url: 'cloud://cloud1-8gylym58ae4d6da9.636c-cloud1-8gylym58ae4d6da9-1382384471/home/swiper images/4.jpg'
    }],
    gridCol: 4,
    iconList: [{
      icon: '../../images/icon/classroomAppointment.png',
      name: '教室预约',
      key: 'classroomAppointment',
      auth: ['student', 'teacher', 'admin'],
    }, {
      icon: '../../images/icon/secondHandTrade.png',
      name: '二手交易',
      key: 'shopping-mall',
      auth: ['student', 'teacher', 'admin'],
    }, {
      icon: '../../images/icon/lostAndFound.png',
      name: '失物招领',
      key: 'index',
      auth: ['student', 'teacher', 'admin'],
    }, {
      icon: '../../images/icon/aiChat.png',
      name: '温大助手',
      key: 'aiChat',
      auth: ['student', 'teacher', 'admin'],
    }],
    tipList: [{
      'text': '温大百宝箱上线啦~'
    }, {
      'text': 'WZU Pocket Online~'
    }, {
      'text': '当前版本为V1.0, 更新了温大助手~'
    }],
  },

  navigateToNewPage: function(event)
  {
    var dst = event.currentTarget.dataset.key
    var authList = event.currentTarget.dataset.authlist
    var user = app.globalData.user
    var auth = user.auth
    var url = '../' + dst + '/' + dst

    if (dst === 'classroomAppointment')
    {
      if (auth === 'student' || auth === 'teacher')
      {
        wx.navigateTo({
          url: '../integratedQuery/integratedQuery',
        })
      }
      else
      {
        wx.navigateTo({
          url: '../Review_Application/Review_Application',
        })
      }
    }

    wx.navigateTo({
      url: url,
    })
  },

  isLogged: function()
  {
    let user = app.globalData.user

    if (!user)
    {
      let timer = setTimeout(() => {
        wx.reLaunch({
          url: '../login/login',
        })
      }, 1000);

      wx.showToast({
        title: '请先登录',
        icon: 'loading',
        mask: true
      })
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    var user = wx.getStorageSync('user')
    app.globalData.user = user

    this.isLogged()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})