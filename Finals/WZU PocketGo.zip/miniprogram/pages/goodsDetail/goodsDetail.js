// pages/goodsDetail/goodsDetail.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    loading: true,
    goodsInfo: null,
    CustomBar: 0,
    showContactModal: false,
    commentsList: [],
    commentContent: '',
    replyingTo: null,
    replyingToAuthor: '',
    goodsId: '',
    currentStudentId: '', // 当前用户的Students集合_id
    isPublisher: false, // 是否是发布者
    isFavorited: false // 是否已收藏
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    const { id } = options;
    if (!id) {
      wx.showToast({ title: '商品不存在', icon: 'none' });
      setTimeout(() => {
        // 检查是否有上一页可以返回
        const pages = getCurrentPages();
        if (pages.length > 1) {
          wx.navigateBack({
            delta: 1,
            fail: () => {
              // 如果返回失败，跳转到主页
              wx.switchTab({
                url: '/pages/shopping-mall/shopping-mall'
              });
            }
          });
        } else {
          // 如果没有上一页，跳转到主页
          wx.switchTab({
            url: '/pages/shopping-mall/shopping-mall'
          });
        }
      }, 1500);
      return;
    }

    // 设置自定义导航栏高度
    const systemInfo = wx.getSystemInfoSync();
    const menuButtonInfo = wx.getMenuButtonBoundingClientRect();
    const customBar = menuButtonInfo.top + menuButtonInfo.height + 8;
    this.setData({ CustomBar: customBar, goodsId: id });

    // 获取当前用户身份（Students集合的_id）
    this.getCurrentStudentId();

    // 获取商品详情
    this.fetchGoodsDetail(id);
    // 获取评论列表
    this.fetchComments(id);
  },

  // 获取商品详情
  fetchGoodsDetail(id) {
    this.setData({ loading: true });
    const db = wx.cloud.database();
    const currentStudentId = this.data.currentStudentId;
    
    db.collection('Goods')
      .doc(id)
      .get()
      .then(res => {
        if (res.data) {
          const goodsInfo = {
            ...res.data,
            displayDate: res.data.createTime ? this.formatDate(res.data.createTime) : ''
          };
          
          // 判断是否是发布者
          const isPublisher = currentStudentId && goodsInfo.publisherId === currentStudentId;
          
          this.setData({
            goodsInfo: goodsInfo,
            isPublisher: isPublisher,
            loading: false
          });
          
          // 如果不是发布者，检查收藏状态
          if (!isPublisher && currentStudentId) {
            this.checkFavoriteStatus(id, currentStudentId);
          }
        } else {
          wx.showToast({ title: '商品不存在', icon: 'none' });
          setTimeout(() => {
            // 检查是否有上一页可以返回
            const pages = getCurrentPages();
            if (pages.length > 1) {
              wx.navigateBack({
                delta: 1,
                fail: () => {
                  // 如果返回失败，跳转到主页
                  wx.switchTab({
                    url: '/pages/shopping-mall/shopping-mall'
                  });
                }
              });
            } else {
              // 如果没有上一页，跳转到主页
              wx.switchTab({
                url: '/pages/shopping-mall/shopping-mall'
              });
            }
          }, 1500);
        }
      })
      .catch(err => {
        console.error('获取商品详情失败', err);
        wx.showToast({ title: '加载失败', icon: 'none' });
        this.setData({ loading: false });
      });
  },

  // 日期格式化
  formatDate(ts) {
    if (!ts) return '';
    // 处理云数据库的Date对象
    const date = ts instanceof Date ? ts : new Date(ts);
    const pad = n => (n < 10 ? `0${n}` : n);
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
  },

  // 预览图片
  previewImage(e) {
    const current = e.currentTarget.dataset.url;
    const urls = this.data.goodsInfo.images || [];
    if (urls.length === 0) return;
    
    wx.previewImage({
      current: current,
      urls: urls
    });
  },

  // 发送私信 - 显示联系方式
  sendMessage() {
    const goodsInfo = this.data.goodsInfo;
    if (!goodsInfo) {
      wx.showToast({ title: '无法获取商品信息', icon: 'none' });
      return;
    }
    // 显示联系方式弹窗
    this.setData({
      showContactModal: true
    });
  },

  // 关闭联系方式弹窗
  closeContactModal() {
    this.setData({
      showContactModal: false
    });
  },

  // 预览微信二维码
  previewWechatQR() {
    const qrCode = this.data.goodsInfo.wechatQRCode;
    if (!qrCode) {
      wx.showToast({ title: '暂无微信二维码', icon: 'none' });
      return;
    }
    wx.previewImage({
      urls: [qrCode],
      current: qrCode
    });
  },

  // 复制联系电话
  copyPhone() {
    const phone = this.data.goodsInfo.contactPhone;
    if (!phone) {
      wx.showToast({ title: '暂无联系电话', icon: 'none' });
      return;
    }
    wx.setClipboardData({
      data: phone,
      success: () => {
        wx.showToast({ title: '联系电话已复制', icon: 'success' });
      }
    });
  },

  // ========== 收藏功能 ==========
  // 检查收藏状态
  checkFavoriteStatus(goodsId, studentId) {
    const db = wx.cloud.database();
    db.collection('Favorites')
      .where({
        goodsId: goodsId,
        studentId: studentId
      })
      .get()
      .then(res => {
        this.setData({
          isFavorited: res.data && res.data.length > 0
        });
      })
      .catch(err => {
        console.error('检查收藏状态失败', err);
      });
  },

  // 切换收藏状态
  toggleFavorite() {
    const { goodsId, currentStudentId, isFavorited, isPublisher } = this.data;
    
    // 检查是否已登录
    if (!currentStudentId) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      return;
    }
    
    // 检查是否是发布者
    if (isPublisher) {
      wx.showToast({ title: '不能收藏自己的商品', icon: 'none' });
      return;
    }

    const db = wx.cloud.database();
    
    if (isFavorited) {
      // 取消收藏
      db.collection('Favorites')
        .where({
          goodsId: goodsId,
          studentId: currentStudentId
        })
        .get()
        .then(res => {
          if (res.data && res.data.length > 0) {
            db.collection('Favorites')
              .doc(res.data[0]._id)
              .remove()
              .then(() => {
                this.setData({ isFavorited: false });
                wx.showToast({ title: '取消收藏', icon: 'success' });
              })
              .catch(err => {
                console.error('取消收藏失败', err);
                wx.showToast({ title: '操作失败', icon: 'none' });
              });
          }
        })
        .catch(err => {
          console.error('查询收藏失败', err);
          wx.showToast({ title: '操作失败', icon: 'none' });
        });
    } else {
      // 添加收藏
      db.collection('Favorites')
        .add({
          data: {
            goodsId: goodsId,
            studentId: currentStudentId,
            createTime: db.serverDate()
          }
        })
        .then(() => {
          this.setData({ isFavorited: true });
          wx.showToast({ title: '已收藏', icon: 'success' });
        })
        .catch(err => {
          console.error('收藏失败', err);
          wx.showToast({ title: '收藏失败', icon: 'none' });
        });
    }
  },

  // ========== 评论区功能 ==========
  // 获取当前用户身份（Students集合的_id）
  getCurrentStudentId() {
    // 方法1: 从app.globalData获取
    const app = getApp();
    if (app.globalData.user && app.globalData.user._id) {
      this.setData({ currentStudentId: app.globalData.user._id });
      // 重新获取商品详情和评论列表以更新状态
      if (this.data.goodsId) {
        this.fetchGoodsDetail(this.data.goodsId);
        this.fetchComments(this.data.goodsId);
      }
      return;
    }

    // 方法2: 从本地存储获取
    try {
      const studentInfo = wx.getStorageSync('studentInfo');
      if (studentInfo && studentInfo._id) {
        this.setData({ currentStudentId: studentInfo._id });
        if (this.data.goodsId) {
          this.fetchGoodsDetail(this.data.goodsId);
          this.fetchComments(this.data.goodsId);
        }
        return;
      }
    } catch (e) {
      console.error('获取本地存储失败', e);
    }

    // 方法3: 从页面参数获取（如果从其他页面传入）
    // 这里可以根据实际情况调整
    console.log('未找到用户身份信息，请确保已登录');
  },

  // 获取评论列表
  fetchComments(goodsId) {
    const db = wx.cloud.database();
    const currentStudentId = this.data.currentStudentId;
    
    db.collection('Comments')
      .where({
        goodsId: goodsId
      })
      .orderBy('createTime', 'desc')
      .get()
      .then(async res => {
        const comments = res.data || [];
        const commentsList = [];
        
        // 遍历评论，关联查询Students集合获取name
        for (let item of comments) {
          let authorName = item.author || '匿名用户';
          
          // 如果评论中有studentId，从Students集合获取name
          if (item.studentId) {
            try {
              const studentRes = await db.collection('Students')
                .doc(item.studentId)
                .get();
              if (studentRes.data && studentRes.data.name) {
                authorName = studentRes.data.name;
              }
            } catch (err) {
              console.error('获取学生信息失败', err);
            }
          }
          
          commentsList.push({
            ...item,
            author: authorName,
            displayTime: item.createTime ? this.formatCommentTime(item.createTime) : '',
            // 标记是否是自己的评论（通过studentId比较）
            isOwn: currentStudentId && item.studentId === currentStudentId
          });
        }
        
        this.setData({ commentsList });
      })
      .catch(err => {
        console.error('获取评论失败', err);
      });
  },

  // 格式化评论时间
  formatCommentTime(ts) {
    if (!ts) return '';
    const date = ts instanceof Date ? ts : new Date(ts);
    const now = new Date();
    const diff = now - date;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return '刚刚';
    if (minutes < 60) return `${minutes}分钟前`;
    if (hours < 24) return `${hours}小时前`;
    if (days < 7) return `${days}天前`;
    
    const pad = n => (n < 10 ? `0${n}` : n);
    return `${date.getMonth() + 1}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
  },

  // 评论输入
  onCommentInput(e) {
    this.setData({
      commentContent: e.detail.value
    });
  },

  // 回复评论
  replyComment(e) {
    const { id, author } = e.currentTarget.dataset;
    this.setData({
      replyingTo: id,
      replyingToAuthor: author
    });
  },

  // 取消回复
  cancelReply() {
    this.setData({
      replyingTo: null,
      replyingToAuthor: '',
      commentContent: ''
    });
  },

  // 提交评论
  submitComment() {
    const content = this.data.commentContent.trim();
    if (!content) {
      wx.showToast({ title: '请输入评论内容', icon: 'none' });
      return;
    }

    // 检查是否已登录
    const currentStudentId = this.data.currentStudentId;
    if (!currentStudentId) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      return;
    }

    this.doSubmitComment(content);
  },

  // 执行提交评论
  doSubmitComment(content) {
    const db = wx.cloud.database();
    const { goodsId, replyingTo, replyingToAuthor, currentStudentId } = this.data;
    
    // 从Students集合获取当前用户name
    db.collection('Students')
      .doc(currentStudentId)
      .get()
      .then(studentRes => {
        const studentName = studentRes.data ? (studentRes.data.name || '匿名用户') : '匿名用户';
        
        // 查找被回复的评论信息
        let replyToAuthor = '';
        if (replyingTo) {
          const replyComment = this.data.commentsList.find(c => c._id === replyingTo);
          replyToAuthor = replyComment ? replyComment.author : replyingToAuthor;
        }

        const commentData = {
          goodsId: goodsId,
          content: content,
          studentId: currentStudentId, // 保存Students集合的_id
          author: studentName, // 保存name用于显示（冗余字段，便于查询）
          createTime: db.serverDate(),
          replyTo: replyingTo || null,
          replyToAuthor: replyToAuthor || null
        };

        db.collection('Comments')
          .add({
            data: commentData
          })
          .then(() => {
            wx.showToast({ title: '评论成功', icon: 'success' });
            // 清空输入
            this.setData({
              commentContent: '',
              replyingTo: null,
              replyingToAuthor: ''
            });
            // 刷新评论列表
            this.fetchComments(goodsId);
          })
          .catch(err => {
            console.error('评论失败', err);
            wx.showToast({ title: '评论失败', icon: 'none' });
          });
      })
      .catch(err => {
        console.error('获取用户信息失败', err);
        wx.showToast({ title: '获取用户信息失败', icon: 'none' });
      });
  },

  // 长按评论
  onCommentLongPress(e) {
    const { id, isown } = e.currentTarget.dataset;
    if (!id) return;
    
    // 只有自己的评论才能删除
    const isOwn = isown === 'true' || isown === true;
    if (isOwn) {
      this.showDeleteConfirm(id);
    } else {
      // 如果不是自己的评论，可以提示
      wx.showToast({ title: '只能删除自己的评论', icon: 'none' });
    }
  },

  // 显示删除确认
  showDeleteConfirm(commentId) {
    wx.showModal({
      title: '删除评论',
      content: '确定要删除这条评论吗？',
      confirmText: '删除',
      confirmColor: '#ff2442',
      success: (res) => {
        if (res.confirm) {
          this.deleteComment(commentId);
        }
      }
    });
  },

  // 删除评论
  deleteComment(commentId) {
    if (!commentId) return;

    const db = wx.cloud.database();
    db.collection('Comments')
      .doc(commentId)
      .remove()
      .then(() => {
        wx.showToast({ title: '删除成功', icon: 'success' });
        // 刷新评论列表
        this.fetchComments(this.data.goodsId);
      })
      .catch(err => {
        console.error('删除评论失败', err);
        wx.showToast({ title: '删除失败', icon: 'none' });
      });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    // 页面显示时重新获取用户身份（可能在其他页面登录了）
    this.getCurrentStudentId();
    // 如果已有商品ID，刷新商品详情和评论列表
    if (this.data.goodsId) {
      this.fetchGoodsDetail(this.data.goodsId);
      this.fetchComments(this.data.goodsId);
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    if (this.data.goodsInfo && this.data.goodsInfo._id) {
      this.fetchGoodsDetail(this.data.goodsInfo._id);
      this.fetchComments(this.data.goodsInfo._id);
    } else {
      wx.stopPullDownRefresh();
    }
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {
    const goodsInfo = this.data.goodsInfo;
    if (goodsInfo) {
      return {
        title: goodsInfo.name || '校园二手商品',
        path: `/pages/goodsDetail/goodsDetail?id=${goodsInfo._id}`,
        imageUrl: goodsInfo.images && goodsInfo.images[0] ? goodsInfo.images[0] : ''
      };
    }
  }
})
