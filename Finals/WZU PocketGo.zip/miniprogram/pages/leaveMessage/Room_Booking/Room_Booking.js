const app = getApp()
const db = wx.cloud.database();

Page({
  data: {
    information: {
      date: "2015-09-01",
      startTime: "",
      endTime: "",
      classroomName: '',
      classroomType: '',
      weekNumber: 0,
      weekday: 0,
      reason: ''
    },
    userName: "",
    phone: "",
    classroomTypePicker: ['普通教室', '阶梯教室', '会议室'],
    classroomTypeIndex: 0,
    standardClassroomPicker: ['5A-102', '5A-103', '5A-104', '5A-202', '5A-203', '5A-204', '5B-206', '5B-211', '5A-302', '5A-303', '5A-304'],
    standardClassroomIndex: 0,
    lectureHallClassroomPicker: ['5A-101', '5A-201', '5A-301'],
    meetingRoomPicker: ['5B-318'],
    index: 0,
    startTimePicker: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],
    filteredTimePicker: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],
    filteredEndTimePicker: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],
    startTimeIndex: 0,
    endTimeIndex: 0,
    startDate: "",
    endDate: "",
    Picker: [],
    weekNumber: 0,
    weekday: 0,
  },  
  NavToNewPage(e) {
    const dst = e.currentTarget.dataset.cur;
    wx.redirectTo({
      url: '../'+dst+'/'+dst,
    })
  },
  classroomTypeChange(e) {
    console.log(e);
    const value = e.detail.value;
    this.setData({
      ['information.classroomType']: this.data.classroomTypePicker[value],
      classroomTypeIndex: value
    });
    const classroomLists = [
      this.data.standardClassroomPicker,
      this.data.lectureHallClassroomPicker,
      this.data.meetingRoomPicker
    ];
    this.setData({
      Picker: classroomLists[value]
    })
  },
  classroomNameChange(e) {
    const value = e.detail.value;
    this.setData({
      index: value,
      ['information.classroomName']: this.data.Picker[value]
    });
  },
  startTimeChange(e) {
    const value = e.detail.value;
    const selectedLesson = this.data.filteredTimePicker[value];

    const newFilteredEndTimePicker = this.data.filteredTimePicker.filter(lesson => lesson >= selectedLesson);
    const newEndTimeIndex = 0;

    this.setData({
      startTimeIndex: value,
      endTimeIndex: newEndTimeIndex,
      filteredEndTimePicker: newFilteredEndTimePicker,
      [`information.startTime`]: selectedLesson,
      [`information.endTime`]: selectedLesson,
    })
  },
  endTimeChange(e) {
    const value = e.detail.value;
    const selectedLesson = this.data.filteredEndTimePicker[value];

    if (selectedLesson < this.data.information.startTime) {
      return wx.showToast({
        title: '结束时间不能早于开始时间',
        icon: 'none'
      });
    }

    this.setData({
      endTimeIndex: value,
      [`information.endTime`]: selectedLesson
    })
  },

  inputText: function (e) {
    const field = e.currentTarget.dataset.field;
    const value = e.detail.value;
    this.setData({
      [`information.${field}`]: value
    });
  },
  getNowDate: function () {
    let currentDate = new Date();
    let year = currentDate.getFullYear();
    let month = currentDate.getMonth() + 1;
    let day = currentDate.getDate();
    return (year + "-" + (month < 10 ? "0" + month : month) + "-" + (day < 10 ? "0" + day : day))
  },
  calculateEndDate: function (startDate) {
    let start = new Date(startDate);
    start.setDate(start.getDate() + 6);
    let endYear = start.getFullYear();
    let endMonth = start.getMonth() + 1;
    let endDay = start.getDate();
    return endYear + "-" + (endMonth < 10 ? "0" + endMonth : endMonth) + "-" + (endDay < 10 ? "0" + endDay : endDay);
  },
  setDate: function () {
    let currentDate = this.getNowDate();
    this.setData({
      startDate: currentDate,
      endDate: this.calculateEndDate(currentDate),
      'information.date': currentDate,
    });
  },
  DateChange: function (e) {
    const newDate = e.detail.value;
    this.setData({
      'information.date': newDate
    });
    this.filterTimePicker(newDate);
  },
  convertDateToWeek(date) {
    const startDate = new Date('2025-09-08');
    const targetDate = new Date(date);
    const timeDiff = targetDate - startDate;
    const dayDiff = timeDiff / (1000 * 3600 * 24);
    const weekNumber = Math.floor(dayDiff / 7) + 1;
    const weekday = targetDate.getDay();
    const weekdays = ['星期天', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
    const weekdayName = weekdays[weekday];
    this.setData({
      weekNumber: weekNumber,
      weekday: weekdayName
    });
  },
  getCurrentLessonNumber() {
    const now = new Date();
    const times = [{
        start: '08:20',
        end: '09:00',
        lesson: 1
      },
      {
        start: '09:05',
        end: '09:45',
        lesson: 2
      },
      {
        start: '10:05',
        end: '10:45',
        lesson: 3
      },
      {
        start: '10:50',
        end: '11:30',
        lesson: 4
      },
      {
        start: '11:35',
        end: '12:15',
        lesson: 5
      },
      {
        start: '13:30',
        end: '14:10',
        lesson: 6
      },
      {
        start: '14:15',
        end: '14:55',
        lesson: 7
      },
      {
        start: '15:15',
        end: '15:55',
        lesson: 8
      },
      {
        start: '16:00',
        end: '16:40',
        lesson: 9
      },
      {
        start: '16:45',
        end: '17:25',
        lesson: 10
      },
      {
        start: '18:30',
        end: '19:10',
        lesson: 11
      },
      {
        start: '19:15',
        end: '19:55',
        lesson: 12
      },
      {
        start: '20:00',
        end: '20:40',
        lesson: 13
      },
    ];

    const nowTimeMinutes = now.getHours() * 60 + now.getMinutes();

    for (let i = 0; i < times.length; i++) {
      const [startHour, startMinute] = times[i].start.split(':').map(Number);
      const [endHour, endMinute] = times[i].end.split(':').map(Number);

      const startTimeMinutes = startHour * 60 + startMinute;
      const endTimeMinutes = endHour * 60 + endMinute;

      if (nowTimeMinutes >= startTimeMinutes && nowTimeMinutes <= endTimeMinutes) {
        return times[i].lesson;
      }
      if (nowTimeMinutes < startTimeMinutes) {
        return times[i].lesson;
      }
    }
    return 15;
  },
  filterTimePicker: function (dateString) {
    const todayString = this.getNowDate();
    let minLesson = 1;

    if (dateString === todayString) {
      minLesson = this.getCurrentLessonNumber();
    }

    const filtered = this.data.startTimePicker.filter(lesson => lesson >= minLesson);

    this.setData({
      filteredTimePicker: filtered,
      filteredEndTimePicker: filtered,
    });

    const currentStartTime = parseInt(this.data.information.startTime);
    if (currentStartTime > 0 && currentStartTime < minLesson) {
      this.setData({
        'information.startTime': '',
        'information.endTime': '',
        startTimeIndex: 0,
        endTimeIndex: 0,
      });
    } else if (currentStartTime >= minLesson) {
      const newStartTimeIndex = filtered.indexOf(currentStartTime);
      const currentEndTime = parseInt(this.data.information.endTime);
      const newEndTimeIndex = filtered.indexOf(currentEndTime);

      this.setData({
        startTimeIndex: newStartTimeIndex > -1 ? newStartTimeIndex : 0,
        endTimeIndex: newEndTimeIndex > -1 ? newEndTimeIndex : 0,
      });
    } else {
      this.setData({
        startTimeIndex: 0,
        endTimeIndex: 0,
      });
    }
  },
  getOccupiedTime(start, end) {
    let numStart = parseInt(start);
    let numEnd = parseInt(end);
    const occupiedTimesList = [];
    for (let i = numStart; i <= numEnd; i++) {
      occupiedTimesList.push(i);
    }
    return occupiedTimesList;
  },
  async checkTimeConflict() {
    const db = wx.cloud.database();
    const {
      information,
      weekNumber,
      weekday
    } = this.data;
    const {
      date,
      classroomName,
      startTime,
      endTime
    } = information;

    const userOccupiedTimes = this.getOccupiedTime(startTime, endTime);

    if (!classroomName || !date) {
      console.error("缺少教室或日期信息，无法检查冲突。");
      return true;
    }

    wx.showLoading({
      title: '检查课程占用...',
      mask: true
    });
    try {
      const courseRes = await db.collection('Course_Schedule')
        .where({
          site: classroomName,
          day_of_week: weekday,
          week: weekNumber > 0 ? db.command.in([weekNumber]) : db.command.exists(false)
        })
        .get();

      if (courseRes.data.length > 0) {
        for (const course of courseRes.data) {
          let courseTimes = [];

          if (Array.isArray(course.time_of_day)) {
            courseTimes = course.time_of_day;
          } else if (typeof course.time_of_day === 'string') {
            courseTimes = course.time_of_day.split(',').map(Number).filter(n => !isNaN(n));
          }

          const conflict = courseTimes.some(time => userOccupiedTimes.includes(time));
          if (conflict) {
            wx.hideLoading();
            return true;
          }
        }
      }
    } catch (e) {
      console.error("查询课程表失败:", e);
      wx.hideLoading();
      wx.showToast({
        title: '检查冲突时发生错误',
        icon: 'none'
      });
      return true;
    }

    wx.showLoading({
      title: '检查预约占用...',
      mask: true
    });
    try {
      const appRes = await db.collection('submittedApplication')
        .where({
          classroomName: classroomName,
          date: date,
          status: 1
        })
        .get();

      if (appRes.data.length > 0) {
        for (const app of appRes.data) {
          if (Array.isArray(app.occupiedTimes)) {
            const conflict = app.occupiedTimes.some(time => userOccupiedTimes.includes(time));
            if (conflict) {
              wx.hideLoading();
              return true;
            }
          }
        }
      }
    } catch (e) {
      console.error("查询预约表失败:", e);
      wx.hideLoading();
      wx.showToast({
        title: '检查冲突时发生错误',
        icon: 'none'
      });
      return true;
    }

    wx.hideLoading();
    return false;
  },
  submit: async function () {
    if (this.data.information.classroomType === "") {
      return wx.showToast({
        title: '教室类型不能为空',
        icon: 'error'
      });
    }
    if (this.data.information.classroomName === "") {
      return wx.showToast({
        title: '教室不能为空',
        icon: 'error'
      });
    }
    if (this.data.information.startTime === "") {
      return wx.showToast({
        title: '开始时间不能为空',
        icon: 'error'
      });
    }

    const selectedDate = new Date(this.data.information.date);
    const today = new Date(this.getNowDate());
    const sevenDaysLater = new Date(today);
    sevenDaysLater.setDate(today.getDate() + 7);

    if (selectedDate.getTime() < today.getTime() || selectedDate.getTime() >= sevenDaysLater.getTime()) {
      return wx.showToast({
        title: '只能预约未来七天内（不含第七天）的教室',
        icon: 'none',
        duration: 2500
      });
    }

    if (selectedDate.getTime() === today.getTime()) {
      const currentLesson = this.getCurrentLessonNumber();
      const startLesson = parseInt(this.data.information.startTime);
      if (startLesson < currentLesson) {
        return wx.showToast({
          title: '不能预约早于当前节次的教室',
          icon: 'none',
          duration: 2500
        });
      }
    }

    this.convertDateToWeek(this.data.information.date);

    const isConflict = await this.checkTimeConflict();

    if (isConflict) {
      return wx.showToast({
        title: '该时段已被占用，请重新选择',
        icon: 'none',
        duration: 2500
      });
    }

    wx.showLoading({
      title: '提交中...',
    });
    const db = wx.cloud.database();
    const submittedApplication = db.collection('submittedApplication');
    try {
      const res = await submittedApplication.add({
        data: {
          userName: app.globalData.user.name,
          phone: app.globalData.user.phone,
          date: this.data.information.date,
          weekNumber: this.data.weekNumber,
          weekday: this.data.weekday,
          occupiedTimes: this.getOccupiedTime(this.data.information.startTime, this.data.information.endTime),
          classroomName: this.data.information.classroomName,
          classroomType: this.data.information.classroomType,
          status: 0,
          createdAt: new Date(),
          reason: this.data.information.reason,
          userId: app.globalData.user._id,
          auth: app.globalData.user.auth
        }
      });
      wx.showToast({
        title: '提交预约成功',
        icon: 'success'
      });
      wx.redirectTo({
        url: '../MyReservation/MyReservation',
      });
      console.log('提交成功', res);
    } catch (err) {
      wx.showToast({
        title: '提交失败，请重试',
        icon: 'none'
      });
      console.error('提交失败', err);
    } finally {
      wx.hideLoading();
    }
  },


  onLoad(options = {}) {
    // 1. 基础时间日期初始化
    this.setDate();
    const user = getApp().globalData.user || {}; // 确保 app 已定义
    
    // 初始化Picker为普通教室列表
    this.setData({
      Picker: this.data.standardClassroomPicker
    });
    
    // 2. 安全获取参数并进行类型转换
    const room = options.selectedRoom || '';
    const date = options.selectedDate || this.getNowDate();
    const startTime = parseInt(options.selectedStartTime) || 1; 
    let typeIdx = 0;
    let roomIdx = 0;
    let currentPicker = this.data.standardClassroomPicker;
    console.log(app.globalData)
    if (room && this.data.meetingRoomPicker.includes(room)) {
      typeIdx = 2;
      currentPicker = this.data.meetingRoomPicker;
      roomIdx = currentPicker.indexOf(room);
    } else if (room && this.data.lectureHallClassroomPicker.includes(room)) {
      typeIdx = 1;
      currentPicker = this.data.lectureHallClassroomPicker;
      roomIdx = currentPicker.indexOf(room);
    } else if (room) {
      typeIdx = 0;
      currentPicker = this.data.standardClassroomPicker;
      roomIdx = currentPicker.indexOf(room);
    }
    this.setData({
      userName: user.name || "",
      phone: user.phone || "",
      classroomTypeIndex: typeIdx,
      Picker: currentPicker,
      index: roomIdx,
      'information.date': date,
      'information.classroomName': room,
      'information.classroomType': this.data.classroomTypePicker[typeIdx],
      'information.startTime': startTime,
      'information.endTime': startTime,
      startTimeIndex: startTime - 1,
      endTimeIndex: startTime - 1
    }, () => {
      if (this.data.information.date) {
        this.filterTimePicker(this.data.information.date);
      }
    });
  
    console.log("回填数据完成:", room, date, startTime);
  },
  onReady() {

  },

  onShow() {

  },

  onHide() {

  },

  onUnload() {

  },

  onPullDownRefresh() {

  },

  onReachBottom() {

  },

  onShareAppMessage() {

  }
})