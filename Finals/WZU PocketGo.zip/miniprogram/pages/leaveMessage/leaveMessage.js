// pages/leaveMessage/leaveMessage.js

const app = getApp()
const db = wx.cloud.database()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    text: '',
    messageList: [{
      'publisher': '',
      'content': '',
      'timeStamp': ''
    }],
    enable: false,
    loading: false,
    scrollTop: 0,
  },

  textareaAInput: function(e)
  {
    let text = e.detail.value
    this.setData({
      text: text
    })
  },

  async submitMessage()
  {
    let text = this.data.text

    if (text === '')
    {
      wx.showToast({
        title: '内容不得为空',
        icon: 'error'
      })

      return
    }

    this.setData({
      enable: true
    })
    let user = app.globalData.user
    let message = {
      'publisher': user.nickname,
      'content': text,
      'timeStamp': this.formatDate()
    }

    await db.collection('LeaveMessage').add({
      data: message
    })

    this.setData({
      [`messageList[${this.data.messageList.length}]`]: message,
      scrollTop: 99999,
      enable: false
    })

    wx.showToast({
      title: '发布成功',
      icon: 'success'
    })
  },

  async loadMessage()
  {
    let result = await db.collection('LeaveMessage').count()
    let total = result.total
    let limit = 20
    let batchTime = Math.ceil(total / limit)
    let task = []

    for (let i = 0; i < batchTime; i++)
    {
      let subtask = db.collection('LeaveMessage').skip(i * limit).get()
      task.push(subtask)
    }

    let res = await Promise.all(task)
    let messageList = []

    for (let i = 0; i < res.length; i++)
    {
      messageList.push(...res[i].data)
    }

    this.setData({
      messageList: messageList,
      scrollTop: 99999,
      loading: false
    })
  },

  formatDate: function()
  {
    var today = new Date()

    var year = today.getFullYear()
    var month = String(today.getMonth() + 1).padStart(2, '0')
    var day = String(today.getDate()).padStart(2, '0')

    var hour = String(today.getHours()).padStart(2, '0')
    var minute = String(today.getMinutes()).padStart(2, '0')
    var second = String(today.getSeconds()).padStart(2, '0')
    
    return `${year}年${month}月${day}日 ${hour}:${minute}:${second}`
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.setData({
      loading: true
    })
    this.loadMessage()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})