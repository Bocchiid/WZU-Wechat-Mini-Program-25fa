// pages/books/books.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    loading: true,
    goodsList: [],
    category: '图书教材'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.fetchGoods();
  },

  // 拉取商品列表（根据category过滤）
  fetchGoods() {
    const db = wx.cloud.database();
    this.setData({ loading: true });
    
    db.collection('Goods')
      .where({
        status: 'published',
        category: '图书教材'
      })
      .orderBy('createTime', 'desc')
      .get()
      .then(res => {
        this.setData({
          goodsList: res.data || [],
          loading: false
        });
        wx.stopPullDownRefresh();
      })
      .catch(() => {
        this.setData({ loading: false });
        wx.showToast({ title: '加载商品失败', icon: 'none' });
      });
  },

  // 跳转商品详情
  goDetail(e) {
    const id = e.currentTarget.dataset.id;
    if (!id) return;
    wx.navigateTo({
      url: `/pages/goodsDetail/goodsDetail?id=${id}`
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    // 返回页面时刷新列表
    if (!this.data.loading) {
      this.fetchGoods();
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    this.fetchGoods();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})
