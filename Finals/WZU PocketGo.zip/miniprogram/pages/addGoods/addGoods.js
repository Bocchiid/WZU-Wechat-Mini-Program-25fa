// pages/addGoods/addGoods.js
Page({

  data: {
    categories: ['生活用品', '图书教材', '其他物品'],
    categoryIndex: 0,
    TabCurIndex: 1, // 当前页面导航索引：0=主页, 1=添加, 2=我的
    CustomBar: 0,
    navHeightRpx: 90, // 导航栏高度（rpx，实际高度90rpx）
    fixedTopHeight: 0, // 固定元素总高度（用于占位）
    productInfo: {
      publisher: '',
      name: '',
      price: '',
      description: '',
      category: '生活用品',
      contactPhone: '',
      wechatQRCode: ''
    },
    imgList: [],
    maxImages: 9,
    editId: '', // 编辑模式下的商品ID
    isEditMode: false, // 是否是编辑模式
    originalGoods: null // 保存原始商品信息，用于比较删除云存储文件
  },

  // ======== 页面导航切换 ========
  NavToNewPage(e) {
    const dst = e.currentTarget.dataset.cur;
    if (dst === 'shopping-mall') {
      wx.redirectTo({
        url: '/pages/shopping-mall/shopping-mall'
      });
    } else if (dst === 'addGoods') {
      wx.redirectTo({
        url: '/pages/addGoods/addGoods'
      });
    } else if (dst === 'about') {
      wx.redirectTo({
        url: '/pages/about/about'
      });
    }
  },

  // ======== 表单通用输入处理 ========
  inputText(e) {
    const field = e.currentTarget.dataset.field;
    const value = e.detail.value;
    this.setData({
      [`productInfo.${field}`]: value
    });
  },

  // ======== 选择类别 ========
  onCategoryChange(e) {
    const index = e.detail.value;
    this.setData({
      categoryIndex: index,
      'productInfo.category': this.data.categories[index]
    });
  },

  // ======== 上传图片 ========
  ChooseImage() {
    wx.chooseImage({
      count: this.data.maxImages - this.data.imgList.length,
      sizeType: ['original', 'compressed'],
      sourceType: ['album'],
      success: (res) => {
        wx.showLoading({ title: '上传中...' });

        const uploadTasks = res.tempFilePaths.map(filePath => {
          const cloudPath = `goods/${Date.now()}_${Math.floor(Math.random() * 1000)}${filePath.match(/\.[^.]+?$/)[0]}`;

          return wx.cloud.uploadFile({
            cloudPath,
            filePath
          }).then(r => r.fileID);
        });

        Promise.all(uploadTasks).then(fileIDs => {
          this.setData({
            imgList: this.data.imgList.concat(fileIDs)
          });
          wx.hideLoading();
          wx.showToast({ title: '上传成功', icon: 'success' });
        });
      }
    });
  },

  // ======== 上传微信二维码 ========
  chooseWechatQR() {
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        wx.showLoading({ title: '上传中...' });
        const filePath = res.tempFilePaths[0];
        const cloudPath = `qrcode/${Date.now()}_${Math.floor(Math.random() * 1000)}${filePath.match(/\.[^.]+?$/)[0]}`;
        
        wx.cloud.uploadFile({
          cloudPath,
          filePath
        }).then(r => {
          this.setData({
            'productInfo.wechatQRCode': r.fileID
          });
          wx.hideLoading();
          wx.showToast({ title: '上传成功', icon: 'success' });
        }).catch(err => {
          wx.hideLoading();
          wx.showToast({ title: '上传失败', icon: 'error' });
        });
      }
    });
  },

  // ======== 预览微信二维码 ========
  previewWechatQR() {
    if (!this.data.productInfo.wechatQRCode) return;
    wx.previewImage({
      urls: [this.data.productInfo.wechatQRCode],
      current: this.data.productInfo.wechatQRCode
    });
  },

  // ======== 删除微信二维码 ========
  deleteWechatQR() {
    wx.showModal({
      title: '提示',
      content: '确定要删除微信二维码吗？',
      success: res => {
        if (res.confirm) {
          const oldQRCode = this.data.productInfo.wechatQRCode;
          
          // 如果是编辑模式且二维码是云存储文件，删除云存储中的文件
          if (this.data.isEditMode && oldQRCode && oldQRCode.startsWith('cloud://')) {
            this.deleteCloudFiles([oldQRCode]).then(() => {
              this.setData({
                'productInfo.wechatQRCode': ''
              });
            });
          } else {
            // 新增模式或本地图片，直接删除
            this.setData({
              'productInfo.wechatQRCode': ''
            });
          }
        }
      }
    });
  },

  // ======== 重置表单 ========
  resetForm() {
    this.setData({
      productInfo: {
        publisher: '',
        name: '',
        price: '',
        description: '',
        category: this.data.categories[0],
        contactPhone: '',
        wechatQRCode: ''
      },
      categoryIndex: 0,
      imgList: []
    });
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 200
    });
  },

  // ======== 预览图片 ========
  ViewImage(e) {
    wx.previewImage({
      urls: this.data.imgList,
      current: e.currentTarget.dataset.url
    });
  },

  // ======== 删除云存储文件的工具函数 ========
  deleteCloudFiles(fileIDs) {
    if (!fileIDs || fileIDs.length === 0) {
      return Promise.resolve();
    }
    
    // 过滤掉空值
    const validFileIDs = fileIDs.filter(id => id && typeof id === 'string');
    if (validFileIDs.length === 0) {
      return Promise.resolve();
    }
    
    // 批量删除云存储文件
    return wx.cloud.deleteFile({
      fileList: validFileIDs
    }).then(res => {
      console.log('删除云存储文件成功', res);
      return res;
    }).catch(err => {
      console.error('删除云存储文件失败', err);
      // 即使删除失败也不影响主流程，只记录错误
      return Promise.resolve();
    });
  },

  // ======== 删除图片 ========
  DelImg(e) {
    wx.showModal({
      title: '提示',
      content: '确定要删除这张图片吗？',
      success: res => {
        if (res.confirm) {
          const index = e.currentTarget.dataset.index;
          const fileID = this.data.imgList[index];
          
          // 如果是编辑模式且图片是云存储文件，删除云存储中的文件
          if (this.data.isEditMode && fileID && fileID.startsWith('cloud://')) {
            this.deleteCloudFiles([fileID]).then(() => {
              this.data.imgList.splice(index, 1);
              this.setData({ imgList: this.data.imgList });
            });
          } else {
            // 新增模式或本地图片，直接删除
            this.data.imgList.splice(index, 1);
            this.setData({ imgList: this.data.imgList });
          }
        }
      }
    });
  },

  // ======== 保存草稿（写入数据库） ========
  saveDraft() {
    const data = {
      ...this.data.productInfo,
      images: this.data.imgList,
      status: 'draft',
      updateTime: Date.now(),
    };

    // 数据库操作 保存草稿
    wx.cloud.database().collection('Goods').add({
      data: data,
      success: res => {
        wx.showToast({ title: '草稿已保存', icon: 'success' });
      },
      fail: err => {
        wx.showToast({ title: '保存失败', icon: 'error' });
      }
    });
  },

  // ======== 发布商品 ========
  publishProduct() {
    const info = this.data.productInfo;

    if (!info.publisher || !info.name || !info.price || !info.description) {
      wx.showToast({ title: '请填写完整信息', icon: 'none' });
      return;
    }
    if (this.data.imgList.length === 0) {
      wx.showToast({ title: '至少上传一张商品图', icon: 'none' });
      return;
    }
    if (!info.contactPhone) {
      wx.showToast({ title: '请输入联系电话', icon: 'none' });
      return;
    }
    if (!info.wechatQRCode) {
      wx.showToast({ title: '请上传微信二维码', icon: 'none' });
      return;
    }

    // 获取当前登录用户ID
    const app = getApp();
    let publisherId = '';
    
    if (app.globalData.user && app.globalData.user._id) {
      publisherId = app.globalData.user._id;
    } else {
      try {
        const studentInfo = wx.getStorageSync('studentInfo');
        if (studentInfo && studentInfo._id) {
          publisherId = studentInfo._id;
        }
      } catch (e) {
        console.error('获取用户信息失败', e);
      }
    }

    if (!publisherId) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      return;
    }

    const db = wx.cloud.database();
    
    // 如果是编辑模式
    if (this.data.isEditMode && this.data.editId) {
      // 编辑模式下，只更新允许修改的字段，不更新publisherId和createTime
      const updateData = {
        publisher: info.publisher,
        name: info.name,
        price: info.price,
        description: info.description || '',
        category: info.category,
        contactPhone: info.contactPhone,
        wechatQRCode: info.wechatQRCode,
        images: this.data.imgList,
        updateTime: db.serverDate()
      };
      
      // 验证必填字段
      if (!updateData.name || !updateData.price || !updateData.description) {
        wx.showToast({ title: '请填写完整信息', icon: 'none' });
        return;
      }
      if (this.data.imgList.length === 0) {
        wx.showToast({ title: '至少上传一张商品图', icon: 'none' });
        return;
      }
      if (!updateData.contactPhone) {
        wx.showToast({ title: '请输入联系电话', icon: 'none' });
        return;
      }
      if (!updateData.wechatQRCode) {
        wx.showToast({ title: '请上传微信二维码', icon: 'none' });
        return;
      }
      
      wx.showLoading({ title: '保存中...' });
      
      // 使用保存的原始商品信息，以便删除被替换的云存储文件
      const originalGoods = this.data.originalGoods;
      const fileIDsToDelete = [];
      
      if (originalGoods) {
        // 比较图片列表，找出被删除的图片
        if (originalGoods.images && Array.isArray(originalGoods.images)) {
          const newImages = this.data.imgList || [];
          originalGoods.images.forEach(oldImageId => {
            if (!newImages.includes(oldImageId)) {
              fileIDsToDelete.push(oldImageId);
            }
          });
        }
        
        // 比较二维码，如果不同则删除旧的
        if (originalGoods.wechatQRCode && 
            originalGoods.wechatQRCode !== updateData.wechatQRCode) {
          fileIDsToDelete.push(originalGoods.wechatQRCode);
        }
      }
      
      // 删除被替换的云存储文件
      this.deleteCloudFiles(fileIDsToDelete).then(() => {
        // 更新商品信息
        return db.collection('Goods')
          .doc(this.data.editId)
          .update({
            data: updateData
          });
      })
        .then(res => {
          wx.hideLoading();
          wx.showToast({ 
            title: '修改成功', 
            icon: 'success',
            duration: 2000
          });
          // 编辑成功后，重置编辑状态
          this.setData({
            editId: '',
            isEditMode: false,
            originalGoods: null
          });
          this.resetForm();
          // 由于是tabbar页面，不需要返回，直接重置表单即可
        })
        .catch(err => {
          wx.hideLoading();
          console.error('修改商品失败', err);
          wx.showToast({ 
            title: '修改失败，请重试', 
            icon: 'none',
            duration: 2000
          });
        });
    } else {
      // 新增模式
      const data = {
        ...info,
        images: this.data.imgList,
        publisherId: publisherId, // 保存发布者的Students集合_id
        status: 'published',
        // 使用服务端时间，系统会自动添加 _id 和 _openid
        createTime: db.serverDate(),
        updateTime: db.serverDate()
      };

      // 【数据库操作】发布商品
      db.collection('Goods').add({
        data: data,
        success: res => {
          wx.showToast({ 
            title: '发布成功', 
            icon: 'success',
          });
          this.resetForm();
        },
        fail: err => {
          wx.showToast({ title: '发布失败', icon: 'error' });
        }
      });
    }
  },

  // ======== 加载商品信息（编辑模式） ========
  loadGoodsInfo(goodsId) {
    console.log('loadGoodsInfo 被调用，goodsId:', goodsId);
    
    if (!goodsId) {
      console.error('商品ID不存在');
      wx.showToast({ title: '商品ID不存在', icon: 'none' });
      return;
    }

    // 获取当前登录用户ID
    const app = getApp();
    let currentStudentId = '';
    
    if (app.globalData.user && app.globalData.user._id) {
      currentStudentId = app.globalData.user._id;
    } else {
      try {
        const studentInfo = wx.getStorageSync('studentInfo');
        if (studentInfo && studentInfo._id) {
          currentStudentId = studentInfo._id;
        }
      } catch (e) {
        console.error('获取用户信息失败', e);
      }
    }

    if (!currentStudentId) {
      wx.showToast({ title: '请先登录', icon: 'none' });
      // 使用 switchTab 返回，因为这是 tabbar 页面
      setTimeout(() => {
        try {
          wx.switchTab({
            url: '/pages/about/about'
          });
        } catch (e) {
          console.error('跳转失败', e);
        }
      }, 1500);
      return;
    }

    wx.showLoading({ title: '加载中...' });
    const db = wx.cloud.database();
    
    db.collection('Goods')
      .doc(goodsId)
      .get()
      .then(res => {
        wx.hideLoading();
        if (res.data) {
          const goods = res.data;
          
          // 验证权限：只有发布者才能编辑
          if (goods.publisherId !== currentStudentId) {
            wx.showToast({ title: '无权限编辑此商品', icon: 'none' });
            // 使用 switchTab 返回，因为这是 tabbar 页面
            setTimeout(() => {
              try {
                wx.switchTab({
                  url: '/pages/about/about'
                });
              } catch (e) {
                console.error('跳转失败', e);
              }
            }, 1500);
            return;
          }
          
          const categoryIndex = this.data.categories.indexOf(goods.category);
          
          // 确保价格转换为字符串（如果是数字）
          const priceStr = goods.price ? String(goods.price) : '';
          
          this.setData({
            productInfo: {
              publisher: goods.publisher || '',
              name: goods.name || '',
              price: priceStr,
              description: goods.description || '',
              category: goods.category || this.data.categories[0],
              contactPhone: goods.contactPhone || '',
              wechatQRCode: goods.wechatQRCode || ''
            },
            categoryIndex: categoryIndex >= 0 ? categoryIndex : 0,
            imgList: goods.images || [],
            originalGoods: goods // 保存原始商品信息，用于后续比较删除云存储文件
          });
        } else {
          wx.showToast({ title: '商品不存在', icon: 'none' });
          // 使用 switchTab 返回，因为这是 tabbar 页面
          setTimeout(() => {
            try {
              wx.switchTab({
                url: '/pages/about/about'
              });
            } catch (e) {
              console.error('跳转失败', e);
            }
          }, 1500);
        }
      })
      .catch(err => {
        wx.hideLoading();
        console.error('加载商品信息失败', err);
        wx.showToast({ title: '加载失败，请重试', icon: 'none' });
        // 使用 switchTab 返回，因为这是 tabbar 页面
        setTimeout(() => {
          try {
            wx.switchTab({
              url: '/pages/about/about'
            });
          } catch (e) {
            console.error('跳转失败', e);
          }
        }, 1500);
      });
  },

  // ======== 生命周期函数 ========
  onLoad(options) {
    console.log('addGoods onLoad 被调用，options:', options);
    // 计算固定定位的高度
    const systemInfo = wx.getSystemInfoSync();
    const menuButtonInfo = wx.getMenuButtonBoundingClientRect();
    const customBar = menuButtonInfo.top + menuButtonInfo.height + 8;
    const navHeightPx = (this.data.navHeightRpx * systemInfo.windowWidth) / 750;
    // 减少一些间距，使布局更紧凑
    const fixedTopHeight = navHeightPx
    this.setData({
      CustomBar: customBar,
      navHeightRpx: navHeightPx,
      fixedTopHeight: fixedTopHeight
    });
    
    // 检查是否有编辑ID（优先从URL参数获取，如果没有则从全局变量获取）
    const editId = options.editId || (getApp().globalData.editGoodsId);
    
    if (editId && !this.data.isEditMode) {
      console.log('检测到编辑模式，editId:', editId);
      
      // 编辑模式：设置编辑ID和模式标志
      this.setData({
        editId: editId,
        isEditMode: true
      });
      
      // 清除全局数据中的editId（避免重复进入编辑模式）
      if (getApp().globalData.editGoodsId) {
        getApp().globalData.editGoodsId = null;
      }
      
      // 加载商品信息
      this.loadGoodsInfo(editId);
    } else {
      // 新增模式，重置表单
      if (!this.data.isEditMode) {
        this.resetForm();
      }
    }
  },

  onShow() {
    console.log('addGoods onShow 被调用');
    // 如果当前不是编辑模式，检查是否需要进入编辑模式（处理从其他页面返回的情况）
    if (!this.data.isEditMode) {
      const app = getApp();
      const editId = app.globalData.editGoodsId;
      
      if (editId) {
        console.log('onShow中检测到编辑模式，editId:', editId);
        this.setData({
          editId: editId,
          isEditMode: true
        });
        app.globalData.editGoodsId = null;
        this.loadGoodsInfo(editId);
      }
    }
  }
})
