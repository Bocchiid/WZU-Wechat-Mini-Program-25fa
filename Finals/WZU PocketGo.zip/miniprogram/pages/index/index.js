const app = getApp()
const db = wx.cloud.database()
import {
  formatTime
} from '../../utils/formatTime'
Page({
  /**
   * 页面的初始数据
   */
  data: {
    CustomBar: app.globalData.CustomBar,
    iconList: [{
      icon: 'upload',
      color: 'pink',
      name: '我要发布',
      path: "addMessage"
    }, {
      icon: 'newshotfill',
      color: 'yellow',
      name: '我的发布',
      path: "myPublish"
    }],
    TabCur: 0,
    TabList: [{
      type: 'lost',
      name: "丢失的物品"
    }, {
      type: 'found',
      name: "捡到的物品"
    }],
    allItems: [],
    selectItems: [],
    searchText: '',
  },
  // 操作条选中
  tabSelect(e) {
    this.setData({
      TabCur: e.currentTarget.dataset.id,
    })
    this.loadingItems()
    // 保持搜索状态
    setTimeout(() => {
      this.keepSearch()
    }, 100)
  },
  // 跳转
  gotoPage(event) {
    const path = event.currentTarget.dataset.path
    const url = '../' + path + '/' + path
    // console.log(url)
    wx.navigateTo({
      url: url
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },
  // 加载物品
  async loadingItems() {
    const TabCur = this.data.TabCur
    const className = this.data.TabList[TabCur].type
    const cnt = await db.collection('LostandFoundItems').where({
      type: className
    }).count()
    const total = cnt.total
    const limit = 20
    const batchTimes = Math.ceil(total / limit)

    var itemsList = []
    var task = []
    for (let i = 0; i < batchTimes; i++) {
      var promise = db.collection('LostandFoundItems').where({
        type: className
      }).skip(i * limit).get()
      task.push(promise)
    }
    await Promise.all(task).then(res => {
      // 把res里的内容加到itemsList里
      for (let i = 0; i < res.length; i++) {
        itemsList = itemsList.concat(res[i].data)
      }
      this.setData({
        selectItems: itemsList.map(item => {
          return {
            ...item,
            publishTime: formatTime(item.publishTime)
          }
        }),
        allItems: itemsList.map(item => {
          return {
            ...item,
            publishTime: formatTime(item.publishTime)
          }
        })
      })
    })
    // 如果有搜索关键词，自动应用搜索过滤
    if (this.data.searchText) {
      this.keepSearch()
    }
  },
  // 搜索
  search(event) {
    var text = event.detail.value
    this.setData({
      searchText: text
    })
    // 直接调用keepSearch方法处理搜索逻辑
    this.keepSearch()
  },
  // 清空搜索
  clearSearch() {
    this.setData({
      searchText: '',
      selectItems: this.data.allItems
    })
  },
  // 跳转到物品详情页
  toDetails(event) {
    const item = event.currentTarget.dataset.item
    const user = wx.getStorageSync('user')
    console.log(user._id, item.publisher)
    if (this.data.TabCur === 1 && user._id !== item.publisher) { 
      // 跳转到认领问卷页面
      var url = "../claimForm/claimForm?info=" + encodeURIComponent(JSON.stringify(item))
      wx.navigateTo({
        url: url
      })
    } else { 
      // 跳转到物品详情页
      var url = "../infoDetails/infoDetails?info=" + encodeURIComponent(JSON.stringify(item))
      wx.navigateTo({
        url: url
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.loadingItems()
  },
  // 保持搜索结果显示
  keepSearch() {
    var text = this.data.searchText
    if (!text) {
      // 如果没有搜索关键词，显示所有物品
      this.setData({
        selectItems: this.data.allItems
      })
      return
    }

    const allItems = this.data.allItems
    var selectItems = []
    for (let i = 0; i < allItems.length; i++) {
      if (allItems[i].name.indexOf(text) != -1) {
        selectItems.push(allItems[i])
      }
    }
    this.setData({
      selectItems: selectItems
    })
    console.log(`搜索"${text}"找到${selectItems.length}个结果`)
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})