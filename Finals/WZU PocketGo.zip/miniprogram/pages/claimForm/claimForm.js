const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    itemInfo: {

    },
    formData: {
      date: '',
      region: '',
      phone: '',
      desc: ''
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    const info = JSON.parse(decodeURIComponent(options.info))
    if (info) {
      this.setData({
        itemInfo: info
      })
    }
  },
  // 填写认领问卷
  inputForm(event) {
    const field = event.currentTarget.dataset.field
    const value = event.detail.value

    this.setData({
      [`formData.${field}`]: value.trim()
    })
  },
  // 提交认领申请
  submitClaim() {
    const itemInfo = this.data.itemInfo
    const formData = this.data.formData

    const name = itemInfo.name
    const publisher = itemInfo.publisher
    const claimer = wx.getStorageSync('user')
    const itemId = itemInfo._id
    const date = formData.date
    const region = formData.region
    const phone = formData.phone
    const desc = formData.desc

    if (!date || !region || !phone) {
      wx.showToast({
        title: '请填完必填项（丢失日期、地点和你的联系方式）',
        icon: 'none'
      })
      return
    }
    wx.showLoading({
      title: '正在提交',
    })
    db.collection('CheckOwner').add({
      data: {
        itemId: itemId,
        name: name,
        publisher: publisher,
        claimer: {
          id: claimer._id,
          name: claimer.name,
        },
        date: date,
        region: region,
        phone: phone,
        desc: desc,
        submitTime: Date.now()
      },
      success: (res) => {
        wx.navigateBack({
          success: (res) => {
            wx.hideLoading()
            wx.showToast({
              title: '提交成功！请等待发布人联系~',
              icon: 'none',
            })
          }
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})