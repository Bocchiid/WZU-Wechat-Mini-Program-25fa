// pages/test/test.js

import {
  decodeArrayBuffer
} from '../../utils/text-decoder';

const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    Custom: app.globalData.Custom,
    TabCur: 1,
    scrollLeft: 0,
    chatHistoryModalName: null,
    selectModalName: null,

    user: {},

    selectModelList: [{
      'name': 'Deepseek',
      'key': 'deepseek',
      'group': 'deepseek'
    }, {
      'name': '豆包',
      'key': 'doubao',
      'group': 'doubao'
    }],
    currentModel: 0,

    InputBottom: 0,
    inputText: '',
    enable: false,

    chatHistoryList: [],

    conversationId: null,
    conversationList: [],
    conversationTitle: '',
    scrollTop: 0
  },

  doNothing: function () {},

  showChatHistoryModal(e) {
    this.setData({
      chatHistoryModalName: e.currentTarget.dataset.target
    })
  },
  hideChatHistoryModal(e) {
    this.setData({
      chatHistoryModalName: null
    })
  },

  showSelectModal(e) {
    this.setData({
      selectModalName: e.currentTarget.dataset.target
    })
  },
  hideSelectModal(e) {
    this.setData({
      selectModalName: null
    })
  },

  async changeSelectModel(e) {
    let idx = e.detail.value
    let selectedModel = this.data.selectModelList[idx]
    this.setData({
      currentModel: idx,
      selectModalName: null
    })
    await this.getChatHistoryList()
    this.setDefaultConversation()

    wx.showToast({
      title: '当前模型：' + selectedModel.name,
      icon: 'none'
    })
  },
  async setDefaultModel() {
    this.setData({
      currentModel: 0,
    })

    await this.getChatHistoryList()
  },

  InputFocus(e) {
    this.setData({
      InputBottom: e.detail.height
    })
  },
  InputBlur(e) {
    this.setData({
      InputBottom: 0
    })
  },
  inputMessage: function (e) {
    let inputText = e.detail.value
    this.setData({
      inputText: inputText
    })
  },

  getChatHistoryList() {
    // 必须 return 这个 Promise，外面的 await 才能生效
    return new Promise((resolve, reject) => {
      let user = this.data.user
      let idx = this.data.currentModel;
      let model = this.data.selectModelList[idx];

      wx.request({
        url: app.globalData.baseURL + `/api/${model.group}/chat-history-list-mp/${user._id}`,
        method: 'GET',
        success: (res) => {
          const list = res.data.chat_history_list || [];
          this.setData({
            chatHistoryList: list
          }, () => {
            // 只有在这里 resolve，onLoad 才会继续走下一行
            resolve(list);
          });
        },
        fail: (err) => {
          reject(err);
        }
      });
    });
  },

  async switchConversation(e) {
    this.setData({
      conversationId: e.currentTarget.dataset.conversationid,
      chatHistoryModalName: null
    })
    this.getConversation()
  },

  async getConversation() {
    let conversationId = this.data.conversationId
    let baseURL = app.globalData.baseURL
    let user = this.data.user
    let idx = this.data.currentModel
    let model = this.data.selectModelList[idx]

    if (!conversationId) return

    wx.request({
      url: `${baseURL}/api/${model.group}/mp/${conversationId}/${user._id}`,
      method: 'GET',
      success: (res) => {
        // console.log(res.data)
        this.setData({
          conversationTitle: res.data.title,
          conversationList: res.data.chat_history,
          scrollTop: 99999
        });
      },
      fail: () => {
        wx.showToast({
          title: '网络异常',
          icon: 'error'
        })
      }
    })
  },

  async sendMessage() {
    let prompt = this.data.inputText

    if (!prompt) {
      wx.showToast({
        title: '发送不得为空',
        icon: 'error'
      })
      return
    }

    this.addMessage('user', prompt)
    this.addMessage('assistant', '')
    this.setData({
      inputText: '',
      enable: true
    })

    this.aiResponse(prompt)
  },

  async aiResponse(prompt) {
    let idx = this.data.currentModel
    let model = this.data.selectModelList[idx]
    let user = this.data.user
    let baseURL = app.globalData.baseURL
    let conversationId = this.data.conversationId

    // 1. 定位 AI 消息在数组中的索引
    // 注意：因为你在 sendMessage 里先 addMessage 了 user 和 assistant，
    // 所以这里的 length - 1 正好就是那条空的 assistant 消息
    let aiMsgIndex = this.data.conversationList.length - 1;

    // 确保请求开始时按钮进入禁用状态
    this.setData({
      enable: true
    });

    // 2. 发起请求 (对接 DeepSeek 或你的后端接口)
    const requestTask = wx.request({
      url: `${baseURL}/api/${model.group}/stream-chat-mp/${user._id}`,
      method: 'POST',
      header: {
        'Content-Type': 'application/json'
      },
      data: {
        conversation_id: conversationId,
        prompt: prompt,
      },
      enableChunked: true, // 开启流式输出

      // 请求彻底结束（不论成功失败或断开连接）时触发
      complete: () => {
        this.setData({
          enable: false
        });
        console.log('网络连接已关闭，执行收尾刷新');

        // 如果是新对话，先本地根据输入预设一个临时标题，防止顶部显示“新对话”
        if (this.data.conversationTitle === '新对话' || !this.data.conversationTitle) {
          this.setData({
            conversationTitle: prompt.substring(0, 15)
          });
        }

        // 延迟执行刷新，确保后端异步写库任务（如生成标题）已完成
        setTimeout(() => {
          // 刷新侧边栏的历史记录列表
          this.getChatHistoryList().then(() => {
            // 重新调用详情接口，同步后端生成的正式 Title
            if (this.data.conversationId) {
              this.getConversation();
            }
          });
        }, 1000);
      }
    });

    // 监听响应头获取 conversation_id (因为后端是在 headers 里传的 ID)
    requestTask.onHeadersReceived((res) => {
      const headers = res.header;
      // 兼容处理不同环境下的 Header 键名大小写
      const newId = headers['conversation_id'] || headers['Conversation_Id'] || headers['conversation-id'];

      if (newId && !this.data.conversationId) {
        console.log('成功捕获到新 ID:', newId);
        this.setData({
          conversationId: newId
        });
      }
    });

    // 3. 监听流式块
    let answer = '';
    requestTask.onChunkReceived((res) => {
      const chunk = decodeArrayBuffer(res.data);

      // 解析 SSE 格式数据
      const lines = chunk.split('\n');
      lines.forEach(line => {
        if (line.startsWith('data: ')) {
          const rawData = line.slice(6);

          // 排除掉 [DONE] 字符串本身，它不属于聊天内容
          if (rawData.trim() === '[DONE]') return;

          if (rawData) {
            try {
              // 尝试按标准 JSON 解析内容
              const json = JSON.parse(rawData);
              const content = json.choices?.[0]?.delta?.content || json.content;
              if (content) {
                answer += content;
              }
            } catch (e) {
              // 如果解析失败（非JSON纯文本），直接累加
              answer += rawData;
            }

            // 统一执行渲染更新
            this.setData({
              [`conversationList[${aiMsgIndex}].content`]: answer,
              // 增加随机数确保 scrollTop 改变触发滚动
              scrollTop: 99999 + Math.random()
            });
          }
        }
      });
    });
  },

  async addMessage(role, content) {
    let message = {
      'role': role,
      'content': content
    }

    this.setData({
      [`conversationList[${this.data.conversationList.length}]`]: message,
      scrollTop: 99999,
    })
  },

  async setDefaultConversation() {
    let chatHistoryList = this.data.chatHistoryList || [];

    if (chatHistoryList.length != 0) {
      let firstId = chatHistoryList[0].conversation_id;
      this.setData({
        conversationId: firstId
      });
      this.getConversation();
      console.log('历史列表不为空, 加载对话中')
    } else {
      this.setData({
        conversationId: null,
        conversationList: [],
        conversationTitle: '新对话'
      });
      console.log('历史列表为空，准备开启新对话');
    }
  },

  async startNewChat() {
    if (this.data.conversationId === null)
    {
      wx.showToast({
        title: '当前已是新对话',
        icon: 'none'
      })

      return
    }

    wx.showModal({
      title: '提示',
      content: '确定要开始一段新的对话吗？',
      success: (res) => {
        if (res.confirm) {
          // 2. 清空当前对话状态
          this.setData({
            conversationId: null, // 重置 ID，让后端生成新 ID
            conversationList: [], // 清空聊天窗口
            conversationTitle: '新对话',
            inputText: '' // 清空输入框
          });

          wx.showToast({
            title: '已开启新对话',
            icon: 'success'
          });
        }
      }
    });
  },

  onLoadUser: function () {
    let user = app.globalData.user
    this.setData({
      user: user
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  async onLoad(options) {
    this.onLoadUser()
    await this.setDefaultModel()
    this.setDefaultConversation()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})