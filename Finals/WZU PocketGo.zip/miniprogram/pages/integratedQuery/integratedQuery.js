// pages/integratedQuery/integratedQuery.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    allRooms: ['5A-102', '5A-103', '5A-202', '5A-203', '5A-204', '5B-206', '5B-211', '5A-302', '5A-303', '5A-304', '5A-101', '5A-201', '5A-301', '5B-318'],
    allTimes: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14],
    SEMESTER_START_DATE: '2025-09-08',
    index: 0,
    TabCur: 0,
    MainCur: 0,
    VerticalNavTop: 0,
    year: 0,
    month: 0,
    today: 0,
    space: 0,
    week: "",
    dateString: "",
    spot: ['2021/11/6', '2020/8/9', '2020/8/20', '2020/9/12'],
    times: [
      ['08:20', '09:00', 1],
      ['09:05', '09:45', 2],
      ['10:05', '10:45', 3],
      ['10:50', '11:30', 4],
      ['11:35', '12:15', 5],
      ['13:30', '14:10', 6],
      ['14:15', '14:55', 7],
      ['15:15', '15:55', 8],
      ['16:00', '16:40', 9],
      ['16:45', '17:25', 10],
      ['18:30', '19:10', 11],
      ['19:15', '19:55', 12],
      ['20:00', '20:40', 13],
      ['20:45', '21:25', 14]
    ],
    selectedStartTime: 0,
    selectedRoom: '',
    load:true,
    roomsStatusList:[]

  },
  NavToNewPage(e) {
    const dst = e.currentTarget.dataset.cur;
    wx.redirectTo({
      url: '../' + dst + '/' + dst,
    })
  },
onMakeReservation(e) {
  const { room, time } = e.currentTarget.dataset;
  const date = this.data.startDate;
  //console.log("准备预约：", { room, time, date });

  if (!room || !time || !date) {
    wx.showToast({
      title: '信息获取失败',
      icon: 'none'
    });
    return;
  }
  this.setData({
    selectedRoom: room,
    selectedStartTime: time
  });

  wx.navigateTo({
    url: `../Room_Booking/Room_Booking?selectedRoom=${room}&selectedStartTime=${time}&selectedDate=${date}`,
  });
},
  tabSelect(e) {
    this.setData({
      TabCur: e.currentTarget.dataset.id,
      MainCur: e.currentTarget.dataset.id,
      VerticalNavTop: (e.currentTarget.dataset.id - 1) * 50
    })
    },
    VerticalMain(e) {
      const {
        roomsStatusList
      } = this.data;
      const scrollTop = e.detail.scrollTop + 20;

      if (this.data.load) {
        const queries = roomsStatusList.map((item, i) =>
          new Promise(resolve => {
            wx.createSelectorQuery()
              .select(`#main-${i}`)
              .boundingClientRect(resolve)
              .exec()
          })
        );

        Promise.all(queries).then(results => {
          const updatedList = results.map((res, i) => ({
            ...roomsStatusList[i],
            top: res.top,
            bottom: res.bottom
          }));
          this.setData({
            roomsStatusList: updatedList,
            load: false
          });
        });
      }

      const activeItem = roomsStatusList.find(item =>
        scrollTop > item.top && scrollTop < item.bottom
      );
      if (activeItem) {
        this.setData({
          VerticalNavTop: (activeItem.id - 1) * 50,
          TabCur: activeItem.id
        });
      }
    },
    /**
     * 生命周期函数--监听页面加载
   */
  getNowTime() {
    const time = new Date();
    this.setData({
      year: time.getFullYear(),
      month: time.getMonth() + 1,
      today: time.getDate(),
      week: time.getDay()
    })
  },
  createDay() {
    let day = [];
    let time = new Date(this.data.year, this.data.month, 0)
    let len = time.getDate()
    for (let i = 1; i <= len; i++) {
      day.push(i);
    }
    this.setData({
      day
    })
  },
  getSpace() {
    let time = new Date(this.data.year, this.data.month - 1, 1);
    time = new Date(time.setDate(0))
    const space = time.getDay();
    this.setData({
      space
    })
  },
  next() {
    let month = this.data.month;
    if (month == 12) {
      this.setData({
        year: this.data.year + 1,
        month: 1
      })
    } else {
      this.setData({
        month: month + 1
      })
    }
    this.getSpace();
    this.createDay();
    this.check();
    this.emit();
  },
  check() {
    let {
      today,
      year,
      month
    } = this.data;
    const time = new Date(year, month, 0);
    let maxDay = time.getDate()
    if (today > maxDay) {
      this.setData({
        today: maxDay
      })
    }
  },
  last() {
    let month = this.data.month;
    if (month == 1) {
      this.setData({
        year: this.data.year - 1,
        month: 12
      })
    } else {
      this.setData({
        month: month - 1
      })
    }
    this.getSpace();
    this.createDay();
    this.check();
    this.emit();
  },
  click(e) {
    let today = e.currentTarget.dataset.today;
    this.setData({
      today
    });
    this.emit();

    const {
      year,
      month
    } = this.data;
    const selectedDate = `${year}-${month.toString().padStart(2, '0')}-${today.toString().padStart(2, '0')}`;
    this.setData({
      startDate: selectedDate
    });
  },
  emit() {
    let {
      year,
      month,
      today
    } = this.data;
    let time = new Date(year, month - 1, today);
    let week = time.getDay();
    week = this.formatWeek(week)
    this.setData({
      year,
      month,
      today,
      week
    })
  },
  formatWeek(data) {
    switch (data) {
      case 1:
        return '一';
      case 2:
        return '二';
      case 3:
        return '三';
      case 4:
        return '四';
      case 5:
        return '五';
      case 6:
        return '六';
      case 0:
        return '日';
    }
  },
  setShow() {
    this.setData({
      show: true
    })
  },
  sureModal(e){
    this.setData({
      show: false
    }),
    this.getAllRoomsStatusByDate();
  },
  hideModal(e) {
    this.setData({
      show: false
    })
  },
  dateChange(e) {
    this.setData({
      dateString: e.detail.dateString
    })
  },
  async fetchAllFromDB(collectionName, filter) {
    const db = wx.cloud.database();
    const MAX_LIMIT = 20;
    let allData = [];
    let skip = 0;
    let hasMore = true;

    while (hasMore) {
      const res = await db.collection(collectionName)
        .where(filter)
        .skip(skip)
        .get();

      allData = allData.concat(res.data);
      if (res.data.length < MAX_LIMIT) {
        hasMore = false;
      } else {
        skip += MAX_LIMIT;
      }
    }
    return allData;
  },

  async getAvailableTimesForDay(date, roomName) {
    const db = wx.cloud.database();
    const weekInfo = this.convertDateToWeek(date);
    const {
      weekNumber,
      weekdayName
    } = weekInfo;
    const occupiedTimesSet = new Set();

    try {
      if (weekNumber > 0) {
        const courseData = await this.fetchAllFromDB('Course_Schedule', {
          site: roomName,
          day_of_week: weekdayName,
          week: db.command.in([weekNumber])
        });

        courseData.forEach(course => {
          if (Array.isArray(course.time_of_day)) {
            course.time_of_day.forEach(t => occupiedTimesSet.add(Number(t)));
          }
        });
      }
      const appData = await this.fetchAllFromDB('submittedApplication', {
        classroomName: roomName,
        date: date,
        status: 1
      });
      appData.forEach(app => {
        if (Array.isArray(app.occupiedTimes)) {
          app.occupiedTimes.forEach(t => occupiedTimesSet.add(Number(t)));
        }
      });
      return this.data.allTimes.filter(t => !occupiedTimesSet.has(Number(t)));
    } catch (error) {
      //console.error(roomName + '查询失败', error);
      return [];
    }
  },

  async getAllRoomsStatusByDate() {
    const {
      startDate,
      allRooms
    } = this.data;
    if (!startDate) return;

    wx.showLoading({
      title: '加载中...'
    });
    try {
      // 并发请求所有教室
      const fetchPromises = allRooms.map(room => this.getAvailableTimesForDay(startDate, room));
      const results = await Promise.all(fetchPromises);

      const roomsStatus = allRooms.map((roomName, index) => {
        return {
          roomName: roomName,
          availableSections: results[index], // 仅含节数数组
          count: results[index].length
        };
      });

      this.setData({
        targetDate: startDate,
        weekInfo: this.convertDateToWeek(startDate),
        roomsStatusList: roomsStatus
      });
    } catch (error) {
      wx.showToast({
        title: '查询失败',
        icon: 'none'
      });
    } finally {
      wx.hideLoading();
    }
  },

  convertDateToWeek(date) {
    const startDate = new Date(this.data.SEMESTER_START_DATE);
    const targetDate = new Date(date);
    if (targetDate < startDate) {
      return {
        weekNumber: 0,
        weekdayName: '学期前'
      };
    }
    const timeDiff = targetDate.getTime() - startDate.getTime();
    const dayDiff = Math.round(timeDiff / (1000 * 3600 * 24));
    const weekNumber = Math.floor(dayDiff / 7) + 1;
    const weekdays = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
    return {
      weekNumber: weekNumber,
      weekdayName: weekdays[targetDate.getDay()]
    };
  },

  // ... 其余日历逻辑 (getNowTime, createDay, getSpace, next, last, check, click, emit, formatWeek) 保持不变 ...


  onLoad(options) {
    this.getNowTime();
    this.getSpace();
    this.createDay();
    this.emit();
    const {
      year,
      month,
      today
    } = this.data;
    const dateStr = `${year}-${month.toString().padStart(2, '0')}-${today.toString().padStart(2, '0')}`;
    this.setData({
      startDate: dateStr
    }, () => {
      this.getAllRoomsStatusByDate();
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})