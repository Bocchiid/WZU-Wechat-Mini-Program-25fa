// pages/about/about.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    TabCur: 0,
    TabCurIndex: 2, // 当前页面导航索引：0=主页, 1=添加, 2=我的
    CustomBar: 0,
    navHeightRpx: 90, // 导航栏高度（rpx，实际高度90rpx）
    fixedTopHeight: 0, // 固定元素总高度（用于占位）
    loading: false,
    myGoodsList: [],
    favoriteGoodsList: [],
    currentStudentId: '',
    modalName: null,
    ListTouchStart: 0,
    ListTouchDirection: null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    // 计算固定定位的高度
    const systemInfo = wx.getSystemInfoSync();
    const menuButtonInfo = wx.getMenuButtonBoundingClientRect();
    const customBar = menuButtonInfo.top + menuButtonInfo.height + 8;
    const navHeightPx = (this.data.navHeightRpx * systemInfo.windowWidth) / 750;
    // 减少一些间距，使布局更紧凑
    const fixedTopHeight =navHeightPx ;
    this.setData({
      CustomBar: customBar,
      navHeightRpx: navHeightPx,
      fixedTopHeight: fixedTopHeight
    });
    this.getCurrentStudentId();
  },

  // 获取当前用户身份
  getCurrentStudentId() {
    const app = getApp();
    let studentId = '';
    
    if (app.globalData.user && app.globalData.user._id) {
      studentId = app.globalData.user._id;
    } else {
      try {
        const studentInfo = wx.getStorageSync('studentInfo');
        if (studentInfo && studentInfo._id) {
          studentId = studentInfo._id;
        }
      } catch (e) {
        console.error('获取本地存储失败', e);
      }
    }

      this.setData({ currentStudentId: studentId });
      this.loadData();

  },

  // 页面导航切换
  NavToNewPage(e) {
    const dst = e.currentTarget.dataset.cur;
    if (dst === 'shopping-mall') {
      wx.redirectTo({
        url: '/pages/shopping-mall/shopping-mall'
      });
    } else if (dst === 'addGoods') {
      wx.redirectTo({
        url: '/pages/addGoods/addGoods'
      });
    } else if (dst === 'about') {
      wx.redirectTo({
        url: '/pages/about/about'
      });
    }
  },

  // Tab切换
  tabSelect(e) {
    const tabId = parseInt(e.currentTarget.dataset.id);
    this.setData({
      TabCur: tabId,
      modalName: null, // 切换tab时关闭滑动菜单
      ListTouchStart: 0,
      ListTouchDirection: null
    });
    this.loadData();
  },

  // 加载数据
  loadData() {
    if (this.data.TabCur === 0) {
      this.fetchMyGoods();
    } else {
      this.fetchFavoriteGoods();
    }
  },

  // 获取我发布的商品
  fetchMyGoods() {
    const studentId = this.data.currentStudentId;
    if (!studentId) return;

    this.setData({ loading: true });
    const db = wx.cloud.database();
    
    db.collection('Goods')
      .where({
        publisherId: studentId
      })
      .orderBy('createTime', 'desc')
      .get()
      .then(res => {
        const myGoodsList = (res.data || []).map(item => ({
          ...item,
          displayDate: item.createTime ? this.formatDate(item.createTime) : ''
        }));
        this.setData({
          myGoodsList,
          loading: false
        });
        wx.stopPullDownRefresh();
      })
      .catch(err => {
        console.error('获取我的商品失败', err);
        wx.showToast({ title: '加载失败', icon: 'none' });
        this.setData({ loading: false });
        wx.stopPullDownRefresh();
      });
  },

  // 获取我收藏的商品
  fetchFavoriteGoods() {
    const studentId = this.data.currentStudentId;
    if (!studentId) return;

    this.setData({ loading: true });
    const db = wx.cloud.database();
    
    // 先获取收藏记录
    db.collection('Favorites')
      .where({
        studentId: studentId
      })
      .orderBy('createTime', 'desc')
      .get()
      .then(res => {
        const favoriteIds = (res.data || []).map(item => item.goodsId);
        
        if (favoriteIds.length === 0) {
          this.setData({
            favoriteGoodsList: [],
            loading: false
          });
          wx.stopPullDownRefresh();
          return;
        }

        // 批量获取商品信息（使用 catch 处理商品不存在的情况）
        const promises = favoriteIds.map(goodsId => 
          db.collection('Goods').doc(goodsId).get().catch(err => {
            // 如果商品不存在（已删除），返回 null
            console.log('商品不存在或已删除:', goodsId, err);
            return { data: null };
          })
        );

        Promise.all(promises)
          .then(results => {
            const favoriteGoodsList = results
              .map((r, index) => {
                // 找到对应的收藏记录
                const favoriteRecord = res.data[index];
                
                // 如果商品不存在（已删除），返回标记为已删除的商品信息
                if (!r.data || !favoriteRecord) {
                  return {
                    _id: favoriteRecord ? favoriteRecord._id : '',
                    goodsId: favoriteRecord ? favoriteRecord.goodsId : '',
                    name: '商品已售出或已下架',
                    price: '',
                    images: [],
                    isDeleted: true, // 标记为已删除
                    displayDate: favoriteRecord && favoriteRecord.createTime ? this.formatDate(favoriteRecord.createTime) : '收藏时间未知'
                  };
                }
                
                return {
                  ...r.data,
                  _id: favoriteRecord._id, // 收藏记录的_id
                  goodsId: r.data._id, // 商品_id
                  isDeleted: false, // 标记为未删除
                  displayDate: favoriteRecord.createTime ? this.formatDate(favoriteRecord.createTime) : '收藏时间未知' // 使用收藏记录的创建时间
                };
              })
              .filter(item => item._id); // 只保留有效的收藏记录
            
            this.setData({
              favoriteGoodsList,
              loading: false
            });
            wx.stopPullDownRefresh();
          })
          .catch(err => {
            console.error('获取收藏商品失败', err);
            wx.showToast({ title: '加载失败', icon: 'none' });
            this.setData({ loading: false });
            wx.stopPullDownRefresh();
          });
      })
      .catch(err => {
        console.error('获取收藏记录失败', err);
        wx.showToast({ title: '加载失败', icon: 'none' });
        this.setData({ loading: false });
        wx.stopPullDownRefresh();
      });
  },

  // 日期格式化
  formatDate(ts) {
    if (!ts) return '';
    const date = ts instanceof Date ? ts : new Date(ts);
    const pad = n => (n < 10 ? `0${n}` : n);
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
  },

  // 左滑操作
  ListTouchStart(e) {
    this.setData({
      ListTouchStart: e.touches[0].pageX
    });
  },

  ListTouchMove(e) {
    this.setData({
      ListTouchDirection: e.touches[0].pageX - this.data.ListTouchStart > 0 ? 'right' : 'left'
    });
  },

  ListTouchEnd(e) {
    if (this.data.ListTouchDirection == 'left') {
      // 左滑：打开菜单
      this.setData({
        modalName: e.currentTarget.dataset.target
      });
    } else if (this.data.ListTouchDirection == 'right') {
      // 右滑：关闭菜单
      this.setData({
        modalName: null
      });
    } else {
      // 点击：关闭菜单（如果当前项已打开则关闭，否则不做处理）
      const currentTarget = e.currentTarget.dataset.target;
      if (this.data.modalName === currentTarget) {
        this.setData({
          modalName: null
        });
      }
    }
    this.setData({
      ListTouchDirection: null
    });
  },

  // 修改商品
  editGoods(e) {
    // 阻止事件继续传播
    if (e && e.stopPropagation) {
      e.stopPropagation();
    }
    
    // 先关闭滑动菜单
    this.setData({ 
      modalName: null,
      ListTouchStart: 0,
      ListTouchDirection: null
    });
    
    const goodsId = e.currentTarget.dataset.id;
    if (!goodsId) {
      wx.showToast({ title: '商品ID不存在', icon: 'none' });
      return;
    }
    
    console.log('准备跳转到编辑页面，商品ID:', goodsId);
    
    // addGoods不是tabbar页面，可以使用navigateTo并传递URL参数
    // 同时设置全局变量作为备用方案
    const app = getApp();
    app.globalData.editGoodsId = goodsId; // 临时存储编辑的商品ID
    
    // 跳转到编辑页面，通过URL参数传递商品ID
    wx.navigateTo({
      url: `/pages/addGoods/addGoods?editId=${goodsId}`,
      success: () => {
        console.log('跳转成功');
      },
      fail: (err) => {
        console.error('跳转失败', err);
        wx.showToast({ title: '跳转失败', icon: 'none' });
        // 清除临时数据
        app.globalData.editGoodsId = null;
      }
    });
  },

  // 删除云存储文件的工具函数
  deleteCloudFiles(fileIDs) {
    if (!fileIDs || fileIDs.length === 0) {
      return Promise.resolve();
    }
    
    // 过滤掉空值
    const validFileIDs = fileIDs.filter(id => id && typeof id === 'string');
    if (validFileIDs.length === 0) {
      return Promise.resolve();
    }
    
    // 批量删除云存储文件
    return wx.cloud.deleteFile({
      fileList: validFileIDs
    }).then(res => {
      console.log('删除云存储文件成功', res);
      return res;
    }).catch(err => {
      console.error('删除云存储文件失败', err);
      // 即使删除失败也不影响主流程，只记录错误
      return Promise.resolve();
    });
  },

  // 删除商品
  deleteGoods(e) {
    // 先关闭滑动菜单
    this.setData({ modalName: null });
    
    const goodsId = e.currentTarget.dataset.id;
    if (!goodsId) {
      wx.showToast({ title: '商品ID不存在', icon: 'none' });
      return;
    }
    
    wx.showModal({
      title: '确认删除',
      content: '确定要删除这个商品吗？删除后无法恢复',
      confirmText: '删除',
      confirmColor: '#ff2442',
      success: (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '删除中...' });
          const db = wx.cloud.database();
          
          // 先获取商品信息，以便删除云存储文件
          db.collection('Goods')
            .doc(goodsId)
            .get()
            .then(goodsRes => {
              const goods = goodsRes.data;
              const fileIDsToDelete = [];
              
              // 收集需要删除的云存储文件ID
              if (goods.images && Array.isArray(goods.images)) {
                fileIDsToDelete.push(...goods.images);
              }
              if (goods.wechatQRCode) {
                fileIDsToDelete.push(goods.wechatQRCode);
              }
              
              // 删除云存储文件
              return this.deleteCloudFiles(fileIDsToDelete).then(() => {
                // 删除商品数据库记录
                return db.collection('Goods').doc(goodsId).remove();
              });
            })
            .then(() => {
              // 删除评论记录（保留收藏记录，让收藏者能看到商品已删除的提示）
              return db.collection('Comments')
                .where({ goodsId: goodsId })
                .get()
                .then(res => {
                  if (res.data && res.data.length > 0) {
                    const deletePromises = res.data.map(item => 
                      db.collection('Comments').doc(item._id).remove()
                    );
                    return Promise.all(deletePromises);
                  }
                });
            })
            .then(() => {
              wx.hideLoading();
              wx.showToast({ title: '删除成功', icon: 'success' });
              // 刷新列表
              this.fetchMyGoods();
            })
            .catch(err => {
              wx.hideLoading();
              console.error('删除失败', err);
              wx.showToast({ title: '删除失败', icon: 'none' });
            });
        }
      }
    });
  },

  // 取消收藏
  cancelFavorite(e) {
    // 先关闭滑动菜单
    this.setData({ modalName: null });
    
    const favoriteId = e.currentTarget.dataset.id;
    const goodsId = e.currentTarget.dataset.goodsid;
    
    if (!favoriteId) {
      wx.showToast({ title: '收藏记录ID不存在', icon: 'none' });
      return;
    }
    
    wx.showModal({
      title: '确认取消',
      content: '确定要取消收藏这个商品吗？',
      confirmText: '取消收藏',
      confirmColor: '#ff2442',
      success: (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '处理中...' });
          const db = wx.cloud.database();
          db.collection('Favorites')
            .doc(favoriteId)
            .remove()
            .then(() => {
              wx.hideLoading();
              wx.showToast({ title: '取消收藏成功', icon: 'success' });
              // 刷新列表
              this.fetchFavoriteGoods();
            })
            .catch(err => {
              wx.hideLoading();
              console.error('取消收藏失败', err);
              wx.showToast({ title: '操作失败', icon: 'none' });
            });
        }
      }
    });
  },

  // 查看商品详情
  viewGoodsDetail(e) {
    // 如果当前有打开的滑动菜单，先关闭
    if (this.data.modalName) {
      this.setData({ modalName: null });
      return; // 如果菜单打开，点击时只关闭菜单，不跳转
    }
    
    const goodsId = e.currentTarget.dataset.id;
    const isDeleted = e.currentTarget.dataset.isdeleted === 'true' || e.currentTarget.dataset.isdeleted === true;
    
    if (!goodsId) {
      wx.showToast({ title: '商品ID不存在', icon: 'none' });
      return;
    }
    
    // 如果商品已删除，提示用户
    if (isDeleted) {
      wx.showModal({
        title: '商品已售出',
        content: '该商品已被发布者删除或已售出，是否取消收藏？',
        confirmText: '取消收藏',
        cancelText: '保留',
        success: (res) => {
          if (res.confirm) {
            // 找到对应的收藏记录并删除
            const favoriteItem = this.data.favoriteGoodsList.find(item => item.goodsId === goodsId);
            if (favoriteItem && favoriteItem._id) {
              const db = wx.cloud.database();
              db.collection('Favorites')
                .doc(favoriteItem._id)
                .remove()
                .then(() => {
                  wx.showToast({ title: '已取消收藏', icon: 'success' });
                  // 刷新列表
                  this.fetchFavoriteGoods();
                })
                .catch(err => {
                  console.error('取消收藏失败', err);
                  wx.showToast({ title: '操作失败', icon: 'none' });
                });
            }
          }
        }
      });
      return;
    }
    
    wx.navigateTo({
      url: `/pages/goodsDetail/goodsDetail?id=${goodsId}`
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    // 页面显示时重新获取用户身份并刷新数据
    this.getCurrentStudentId();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {
    // 关闭滑动菜单
    this.setData({ modalName: null });
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {
    this.loadData();
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})
