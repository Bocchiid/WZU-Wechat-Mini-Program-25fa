// pages/shopping-mall/shopping-mall.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
      loading: true,
      CustomBar:0,
      TabCurIndex: 0, // 当前页面导航索引：0=主页, 1=添加, 2=我的
      navHeightRpx: 90, // 导航栏高度（rpx，实际高度90rpx）
      searchHeightRpx: 88, // 搜索栏高度（rpx，包含padding约88rpx）
      fixedTopHeight: 0, // 固定元素总高度（用于占位）
      goodsList: [],
      searchKeyword: '',
    searchTimer: null,
      swiperList:[
        {url:'cloud://cloud1-8gylym58ae4d6da9.636c-cloud1-8gylym58ae4d6da9-1382384471/shopping-mall-images/swiper1.png'},
        {
          url:'cloud://cloud1-8gylym58ae4d6da9.636c-cloud1-8gylym58ae4d6da9-1382384471/shopping-mall-images/swiper2.jpg'
        },
        {
          url:'cloud://cloud1-8gylym58ae4d6da9.636c-cloud1-8gylym58ae4d6da9-1382384471/shopping-mall-images/swiper3.jpg'
        },
        {
          url:'cloud://cloud1-8gylym58ae4d6da9.636c-cloud1-8gylym58ae4d6da9-1382384471/shopping-mall-images/swiper4.jpg'
        }
      ],
      iconList: [{
          icon: '../../images/icon/necessity.jpg',
          name: '生活用品',
          key: 'necessity'
        }, {
          icon: '../../images/icon/books.png',
          name: '图书教材',
          key: 'books'
        },
        {
          icon: '../../images/icon/else.png',
          name: '其他物品',
          key: 'else'
        },
      ],
      gridCol:3,

    },

    // 页面导航切换
    NavToNewPage(e) {
      const dst = e.currentTarget.dataset.cur;
      if (dst === 'shopping-mall') {
        wx.redirectTo({
          url: '/pages/shopping-mall/shopping-mall'
        });
      } else if (dst === 'addGoods') {
        wx.redirectTo({
          url: '/pages/addGoods/addGoods'
        });
      } else if (dst === 'about') {
        wx.redirectTo({
          url: '/pages/about/about'
        });
      }
    },

    navigateToNewPage: function(event)
    {
      var dst = event.currentTarget.dataset.key

      var url = '../' + dst + '/' + dst

      wx.navigateTo({
        url: url,
      })
    },

    // 拉取商品列表
    fetchGoods(keyword = '') {
      const db = wx.cloud.database();
      let where = { status: 'published' };

      // 关键字搜索（商品名或描述）
      if (keyword) {
        const reg = db.RegExp({
          regexp: keyword,
          options: 'i'
        });
        where = {
          ...where,
          name: reg
        };
      }

      this.setData({ loading: true });
      db.collection('Goods')
        .where(where)
        .orderBy('createTime', 'desc')
        .get()
        .then(res => {
          this.setData({
          goodsList: (res.data || []).map(item => ({
            ...item,
            displayDate: item.createTime ? this.formatDate(item.createTime) : ''
          })),
            loading: false
          });
          wx.stopPullDownRefresh();
        })
        .catch(() => {
          this.setData({ loading: false });
          wx.showToast({ title: '加载商品失败', icon: 'none' });
        });
    },

    // 搜索输入
    selectProds(e) {
      const keyword = e.detail.value.trim();
    // 简单防抖，减少云函数调用频率
    if (this.data.searchTimer) {
      clearTimeout(this.data.searchTimer);
    }
    const timer = setTimeout(() => {
      this.setData({ searchKeyword: keyword, searchTimer: null });
      this.fetchGoods(keyword);
    }, 300);
    this.setData({ searchTimer: timer });
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
      const systemInfo = wx.getSystemInfoSync();
      const menuButtonInfo = wx.getMenuButtonBoundingClientRect();
      const customBar = menuButtonInfo.top + menuButtonInfo.height + 8;
      // 将rpx转换为px：rpx值 * 屏幕宽度 / 750
      const navHeightPx = (this.data.navHeightRpx * systemInfo.windowWidth) / 750;
      const searchHeightPx = (this.data.searchHeightRpx * systemInfo.windowWidth) / 750;
      // 减少一些间距，使布局更紧凑
      const fixedTopHeight = customBar ;
      this.setData({
        CustomBar: customBar,
        navHeightRpx: navHeightPx,
        searchHeightRpx: searchHeightPx,
        fixedTopHeight: fixedTopHeight
      });
      this.fetchGoods();
    },

    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
      // 返回页面时保持列表最新
      if (!this.data.loading) {
        this.fetchGoods(this.data.searchKeyword);
      }
    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {
    if (this.data.searchTimer) {
      clearTimeout(this.data.searchTimer);
    }
    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {
      this.fetchGoods(this.data.searchKeyword);
    },

    // 跳转商品详情
    goDetail(e) {
      const id = e.currentTarget.dataset.id;
      if (!id) return;
      wx.navigateTo({
        url: `/pages/goodsDetail/goodsDetail?id=${id}`
      });
    },

  // 日期格式化
  formatDate(ts) {
    const d = new Date(ts);
    const pad = n => (n < 10 ? `0${n}` : n);
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})