const db = wx.cloud.database()
import { formatTime } from '../../utils/formatTime'
Page({
  /**
   * 页面的初始数据
   */
  data: {
    TabCur: 0,
    TabList: [{
      type: 'lost',
      name: "丢失的物品"
    }, {
      type: 'found',
      name: "捡到的物品"
    }],
    allItems: [],
    selectItems: [],
    user: null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    const user = wx.getStorageSync('user')
    this.setData({
      user: user
    })
    this.loadingItems()
  },
  // 操作条选中
  tabSelect(e) {
    this.setData({
      TabCur: e.currentTarget.dataset.id,
    })
    this.loadingItems()
  },
  // 加载物品
  async loadingItems() {
    const TabCur = this.data.TabCur
    const className = this.data.TabList[TabCur].type
    const user_id = this.data.user._id
    
    const cnt = await db.collection('LostandFoundItems').where({
      type: className,
      publisher: user_id
    }).count()
    const total = cnt.total
    const limit = 20
    const batchTimes = Math.ceil(total / limit)

    var itemsList = []
    var task = []
    for (let i = 0; i < batchTimes; i++) {
      var promise = db.collection('LostandFoundItems').where({
        type: className,
        publisher: user_id
      }).skip(i * limit).get()
      task.push(promise)
    }
    await Promise.all(task).then(res => {
      // 把res里的内容加到itemsList里
      for (let i = 0; i < res.length; i++) {
        itemsList = itemsList.concat(res[i].data)
      }
      this.setData({
        selectItems: itemsList.map(item => {
          return {
            ...item,
            publishTime: formatTime(item.publishTime)
          }
        }),
        allItems: itemsList.map(item => {
          return {
            ...item,
            publishTime: formatTime(item.publishTime)
          }
        })
      })
    })
  },
  // 跳转到物品详情页
  toDetails(event) {
    const item = event.currentTarget.dataset.item
    // 使用encodeURIComponent对JSON字符串进行URL编码
    var url = "../infoDetails/infoDetails?info=" + encodeURIComponent(JSON.stringify(item))
    wx.navigateTo({
      url: url
    })
  },
  // 删除物品
  deleteItem(event) {
    const id = event.currentTarget.dataset.id
    wx.showModal({
      content: '确定要删除这条记录吗？',
      success: (res) => {
        if (res.confirm) {
          db.collection('LostandFoundItems').doc(id).remove().then(() => {
            wx.showToast({
              title: '删除成功',
              icon: 'success',
              success: () => {
                this.loadingItems()
              }
            })
          }).catch(err => {
            console.error(err)
            wx.showToast({
              title: '删除失败',
              icon: 'none'
            })
          })
        }
      }
    })
  },
  // 更新记录
  updateItem(event) {
    const id = event.currentTarget.dataset.id
    
    wx.navigateTo({
      url: "../addMessage/addMessage?id=" + id
    })
  },
  // 跳转到查看认领页
  toCheck(event) {
    const id = event.currentTarget.dataset.id
    
    wx.navigateTo({
      url: "../checkList/checkList?id=" + id
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.loadingItems()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})