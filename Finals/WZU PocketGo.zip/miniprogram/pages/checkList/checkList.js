const db = wx.cloud.database()
import { formatTime } from '../../utils/formatTime'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    itemId: '',
    user: null,
    claimList: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    const id = options.id
    const user = wx.getStorageSync('user')
    if (id) {
      this.setData({
        itemId: id,
        user: user
      })
    }
    this.loadingClaimList()
  },
  // 加载消息列表
  async loadingClaimList() {
    const itemId = this.data.itemId
    const user = this.data.user

    const cnt = await db.collection('CheckOwner').where({
      itemId: itemId,
      publisher: user._id
    }).count()
    const total = cnt.total
    const limit = 20
    const batchTimes = Math.ceil(total / limit)

    var itemsList = []
    var task = []
    for (let i = 0; i < batchTimes; i++) {
      var promise = db.collection('CheckOwner').where({
        itemId: itemId,
        publisher: user._id
      }).skip(i * limit).get()
      task.push(promise)
    }
    await Promise.all(task).then(res => {
      for (let i = 0; i < res.length; i++) {
        itemsList = itemsList.concat(res[i].data)
      }
      this.setData({
        claimList: itemsList.map(item => {
          return {
            ...item,
            submitTime: formatTime(item.submitTime)
          }
        })
      })
    })
  },
  // 跳转到认领详情页
  toDetails(event) {
    const claimData = event.currentTarget.dataset.claimdata
    if (claimData) {
      var url = "../checkDetails/checkDetails?claimData=" + encodeURIComponent(JSON.stringify(claimData))
      wx.navigateTo({
        url: url
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})