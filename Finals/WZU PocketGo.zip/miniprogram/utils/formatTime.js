export const formatTime = (time) => {
  const date = new Date(time);
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  // 有需要再加时分秒
  // const hour = date.getHours();
  // const minute = date.getMinutes();
  // const second = date.getSeconds();
  // return `${year}-${month}-${day} ${hour}:${minute}:${second}`;
  return `${year}年${month}月${day}日`
}